"""
JARVIS za Windows (besplatna verzija, koristi Google Gemini besplatni ključ)

PRIPREMA (jednom):  dvoklik na instaliraj_jarvis.bat
  Ključ uzmi na https://aistudio.google.com/apikey (prijava Google nalogom, bez kartice).

POKRETANJE:
  python jarvis.py            tekst (kucaš)
  python jarvis.py --glas     govoriš i on govori (treba mikrofon)
  python jarvis.py --cekaj    uvijek sluša; reci "Jarvis, ..." i on odgovori (kao Siri)
  python jarvis.py --test     provjera zvučnika i mikrofona na laptopu

ŠTA RADI: odgovara na pitanja, kaže vrijeme/datum, otvara aplikacije s popisa,
traži na Googleu/YouTubeu, postavlja podsjetnike i pamti bilješke.
Ne izvršava proizvoljne komande, nego samo alate koje sam dozvoliš u ovoj datoteci.
Napomena: besplatni nivo ima dnevna ograničenja. Google može koristiti poruke poslane
preko besplatnog nivoa za poboljšanje svojih proizvoda, zato ne govori lozinke i slične stvari.
"""
import os, sys, subprocess, threading, datetime, webbrowser, urllib.parse

if getattr(sys, "frozen", False):                      # spakovano u Jarvis.exe: podaci idu u %APPDATA%\\Jarvis
    HERE = os.path.join(os.environ.get("APPDATA", os.path.expanduser("~")), "Jarvis")
    try: os.makedirs(HERE, exist_ok=True)
    except Exception: pass
else:
    HERE = os.path.dirname(os.path.abspath(__file__))
CEKAJ = "--cekaj" in sys.argv
GLAS = "--glas" in sys.argv or CEKAJ
TEST = "--test" in sys.argv
WAKE = ("jarvis", "džarvis", "žarvis", "čarvis", "jarvi", "garvis", "yarvis", "jarvisu", "jarvisa")

# kad radi skriveno (pythonw), nema konzole pa ispis ide u datoteku
if sys.stdout is None:
    sys.stdout = sys.stderr = open(os.path.join(HERE, "jarvis_log.txt"), "a", encoding="utf-8")

try:
    from google import genai
    from google.genai import types
except ImportError:
    sys.exit("Nedostaje paket. Upiši u CMD:  python -m pip install google-genai pyttsx3")

# Modeli se probaju redom (ako prvi ne postoji, uzima se sljedeći)
MODELI = ["gemini-3.5-flash", "gemini-2.5-flash"]
BILJESKE = os.path.join(HERE, "jarvis_biljeske.txt")

def _ime():
    """Ime korisnika se čita iz datoteke ime.txt (ako je prazna, Jarvis ne oslovljava imenom)."""
    try:
        with open(os.path.join(HERE, "ime.txt"), encoding="utf-8-sig") as f:
            return f.read().strip()
    except Exception:
        return ""

IME = _ime()
ADRESA = ("Korisnika oslovljavaj samo imenom '" + IME + "' (nikad 'gospodine'). ") if IME else "Korisnika ne oslovljavaj imenom. "

SYSTEM = (
    "Ti si JARVIS, lični asistent koji radi na korisnikovom Windows računaru. " + ADRESA +
    "Odgovaraj na bosanskom jeziku, kratko i jasno (1 do 3 rečenice), bez tabela i zvjezdica, "
    "jer se odgovori često čitaju naglas. "
    "Koristi alate kad god korisnik traži vrijeme, otvaranje aplikacije, pretragu, podsjetnik ili bilješku. "
    "Ne možeš sam pretraživati internet, ali možeš otvoriti pretragu u pregledniku. "
    "Ako nešto ne možeš, reci iskreno."
)

# Aplikacije koje Jarvis smije otvoriti (dodaj svoje: ime -> naredba)
APLIKACIJE = {
    "kalkulator": "calc.exe", "notepad": "notepad.exe", "bilježnica": "notepad.exe",
    "paint": "mspaint.exe", "istraživač datoteka": "explorer.exe", "task manager": "taskmgr.exe",
    "postavke": "ms-settings:", "word": "winword.exe", "excel": "excel.exe",
    "chrome": "chrome.exe", "edge": "msedge.exe",
}

# ---------- glas (nije obavezan) ----------
tts = None
if GLAS:
    try:
        import pyttsx3
        tts = pyttsx3.init()
    except Exception as e:
        print("Govor nije dostupan:", e)

def reci(tekst):
    print("\nJarvis:", tekst)
    if tts:
        tts.say(tekst); tts.runAndWait()

_rec = None
def slusaj(timeout=None, limit=15, tiho=False):
    global _rec
    try:
        import speech_recognition as sr
    except ImportError:
        sys.exit("Za glas instaliraj:  python -m pip install SpeechRecognition pyaudio")
    if _rec is None:
        _rec = sr.Recognizer()
    with sr.Microphone() as izvor:
        if not tiho:
            print("\n[slušam...]")
        _rec.adjust_for_ambient_noise(izvor, 0.4)
        try:
            zvuk = _rec.listen(izvor, timeout=timeout, phrase_time_limit=limit)
        except sr.WaitTimeoutError:
            return ""
    try:
        return _rec.recognize_google(zvuk, language="hr-HR")
    except Exception:
        return ""

def cekaj_jarvisa():
    """Čeka riječ 'Jarvis'. Vraća naredbu koja je rečena uz nju (ili nakon 'Slušam')."""
    while True:
        t = slusaj(timeout=6, limit=10, tiho=True).lower().strip()
        if not t or not any(w in t for w in WAKE):
            continue
        for w in sorted(WAKE, key=len, reverse=True):
            t = t.replace(w, " ")
        t = t.strip(" ,.!?")
        if t:
            return t
        reci("Slušam.")
        t = slusaj(timeout=8, limit=15)
        if t:
            return t

def provjeri_zvuk():
    print("== PROVJERA ZVUKA ==")
    try:
        out = subprocess.run(["powershell", "-NoProfile", "-Command",
            "Get-CimInstance Win32_SoundDevice | Select-Object -ExpandProperty Name"],
            capture_output=True, text=True, timeout=20).stdout.strip()
        print("Audio uređaji u računaru:\n" + (out or "  (nijedan nije pronađen)"))
    except Exception as e:
        print("Ne mogu pročitati uređaje:", e)
    try:
        import winsound; print("Puštam zvučni signal... čuješ li ga?"); winsound.Beep(800, 700)
    except Exception as e:
        print("Beep nije uspio:", e)
    if tts:
        reci("Ako me čuješ, zvučnik radi.")
    else:
        print("(Za provjeru govora pokreni:  python jarvis.py --glas --test)")
    try:
        import speech_recognition as sr
        print("Mikrofoni:", sr.Microphone.list_microphone_names() or "nijedan")
    except Exception as e:
        print("Mikrofon: treba 'python -m pip install SpeechRecognition pyaudio' (", e, ")")

# ---------- alati (Gemini ih poziva sam; opis i tipovi su bitni) ----------
def vrijeme_datum() -> str:
    """Vraća trenutni datum i vrijeme."""
    return datetime.datetime.now().strftime("%A, %d.%m.%Y, %H:%M")

def otvori_aplikaciju(naziv: str) -> str:
    """Otvara aplikaciju na računaru. Dozvoljeno: kalkulator, notepad, bilježnica, paint,
    istraživač datoteka, task manager, postavke, word, excel, chrome, edge."""
    ime = naziv.lower().strip()
    if ime not in APLIKACIJE:
        return "Tu aplikaciju ne smijem otvoriti. Dozvoljene: " + ", ".join(APLIKACIJE)
    try:
        os.startfile(APLIKACIJE[ime])
        return f"Otvoreno: {ime}."
    except Exception as e:
        return f"Nije uspjelo otvaranje: {e}"

def trazi(upit: str, gdje: str = "google") -> str:
    """Otvara pretragu u pregledniku. Parametar gdje je 'google' ili 'youtube'."""
    q = urllib.parse.quote_plus(upit)
    if gdje == "youtube":
        webbrowser.open("https://www.youtube.com/results?search_query=" + q)
    else:
        webbrowser.open("https://www.google.com/search?q=" + q)
    return "Pretraga otvorena u pregledniku."

def podsjetnik(minuta: float, poruka: str = "Podsjetnik") -> str:
    """Postavlja podsjetnik koji se oglasi nakon zadanog broja minuta."""
    m = max(0.1, min(float(minuta), 720))
    def okini():
        try:
            import winsound; winsound.Beep(900, 500)
        except Exception:
            pass
        reci("Podsjetnik: " + poruka)
    threading.Timer(m * 60, okini).start()
    return f"Podsjetnik postavljen za {m:g} min."

def sacuvaj_biljesku(tekst: str) -> str:
    """Sprema bilješku u datoteku."""
    with open(BILJESKE, "a", encoding="utf-8") as f:
        f.write(f"[{datetime.datetime.now():%d.%m.%Y %H:%M}] {tekst}\n")
    return "Bilješka sačuvana."

def procitaj_biljeske() -> str:
    """Čita sačuvane bilješke."""
    if not os.path.exists(BILJESKE):
        return "Nema bilješki."
    return open(BILJESKE, encoding="utf-8").read()[-3000:]

ALATI = [vrijeme_datum, otvori_aplikaciju, trazi, podsjetnik, sacuvaj_biljesku, procitaj_biljeske]

# ---------- glavna petlja ----------
def novi_razgovor(klijent, i):
    return klijent.chats.create(model=MODELI[i], config=types.GenerateContentConfig(
        system_instruction=SYSTEM, tools=ALATI))

def main():
    if TEST:
        provjeri_zvuk(); return
    if not (os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY")):
        sys.exit('Nedostaje ključ. Pokreni instaliraj_jarvis.bat ili u CMD-u upiši:\n'
                 '  setx GEMINI_API_KEY "tvoj_kljuc"\npa ponovo otvori CMD.')
    klijent = genai.Client()
    mi = 0
    chat = novi_razgovor(klijent, mi)
    if CEKAJ:
        reci("Jarvis je spreman. Reci Jarvis kad ti trebam.")
    else:
        reci("Zdravo, ja sam Jarvis. Kako ti mogu pomoći? (kaži ili napiši 'kraj' za izlaz)")
    while True:
        unos = cekaj_jarvisa() if CEKAJ else (slusaj() if GLAS else input("\nTi: "))
        if not unos.strip():
            continue
        if GLAS:
            print("Ti:", unos)
        if unos.lower().strip() in ("kraj", "izlaz", "exit", "quit", "ugasi se"):
            reci("Doviđenja."); break
        try:
            o = chat.send_message(unos)
            reci((o.text or "Gotovo.").replace("*", ""))
        except Exception as e:
            g = str(e)
            if ("404" in g or "NOT_FOUND" in g) and mi + 1 < len(MODELI):
                mi += 1; chat = novi_razgovor(klijent, mi)   # probaj stariji model
                reci("Prebacujem na drugi model, ponovi pitanje.")
            elif "429" in g or "RESOURCE_EXHAUSTED" in g:
                reci("Dostignut je besplatni limit. Pričekaj minut-dvije ili pokušaj sutra.")
            elif "API key" in g or "401" in g or "403" in g or "400" in g and "key" in g.lower():
                reci("Problem s ključem. Provjeri GEMINI_API_KEY (instaliraj_jarvis.bat ga ponovo postavlja).")
            else:
                print("Greška:", g)

if __name__ == "__main__":
    main()
