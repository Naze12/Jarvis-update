"""
J.A.R.V.I.S. - prozor (UI) + slušanje u pozadini.
Koristi alate i postavke iz jarvis.py (mora biti u istom folderu).
Pokretanje: dvoklik na prečicu "Jarvis" (pravi je napravi_precicu.bat). Bez crnog prozora.
  --pozadina   pokreće se skriveno i čeka riječ "Jarvis"
Ako se ne otvori, pogledaj datoteku jarvis_error.txt u ovom folderu.
"""
import os, sys, re, json, math, time, queue, socket, difflib, importlib.util, threading, subprocess, traceback, random, bisect, functools

FROZEN = getattr(sys, "frozen", False)                                     # True kad je spakovano u Jarvis.exe
HERE = os.path.dirname(os.path.abspath(sys.executable if FROZEN else __file__))
BASE = getattr(sys, "_MEIPASS", HERE)                                      # resursi: ikona i zvukovi
DATA = os.path.join(os.environ.get("APPDATA", os.path.expanduser("~")), "Jarvis") if FROZEN else HERE   # postavke, historija, pamćenje...
try: os.makedirs(DATA, exist_ok=True)
except Exception: pass
sys.path.insert(0, HERE)
os.chdir(DATA)

BUILD, VERZIJA = 34, "2.6"        # povećaj BUILD pri svakoj izmjeni: po njemu se prepoznaje novo ažuriranje
AZUR_FAJL = os.path.join(DATA, "azuriranje.txt")
ALLOWED_EXT = (".py", ".wav", ".ico", ".png", ".txt", ".json")

def res(ime):
    """Resurs (ikona, zvuk): prvo iz foldera sa ažuriranjima (DATA/kod), pa iz programa."""
    p = os.path.join(DATA, "kod", ime)
    return p if os.path.exists(p) else os.path.join(BASE, ime)

def azur_url():
    for pth in (AZUR_FAJL, os.path.join(BASE, "azuriranje.txt"), os.path.join(HERE, "azuriranje.txt")):
        try:
            with open(pth, encoding="utf-8-sig") as f:
                u = f.read().strip().splitlines()[0].strip()
            if u.startswith("http"): return u
        except Exception:
            pass
    return ""

# --- nikad crni prozor: ako je pokrenut preko python.exe, ponovo se pokreće preko pythonw.exe ---
if os.name == "nt" and "--debug" not in sys.argv:
    try:
        if os.path.basename(sys.executable).lower() == "python.exe":
            pw = os.path.join(os.path.dirname(sys.executable), "pythonw.exe")
            if os.path.exists(pw):
                subprocess.Popen([pw, os.path.abspath(__file__)] + sys.argv[1:], creationflags=0x00000008)
                sys.exit(0)
        import ctypes
        h = ctypes.windll.kernel32.GetConsoleWindow()
        if h: ctypes.windll.user32.ShowWindow(h, 0)
    except SystemExit:
        raise
    except Exception:
        pass

# svaki pomoćni proces (flac pretvarač za govor, PowerShell za glas...) pokreće se bez ikakvog prozora
if os.name == "nt":
    _OrigPopen = subprocess.Popen

    class _SkrivenPopen(_OrigPopen):
        def __init__(self, *a, **k):
            try:
                k["creationflags"] = k.get("creationflags", 0) | 0x08000000        # CREATE_NO_WINDOW
                si = k.get("startupinfo") or subprocess.STARTUPINFO()
                si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                si.wShowWindow = 0                                                  # SW_HIDE
                k["startupinfo"] = si
            except Exception:
                pass
            super().__init__(*a, **k)

    subprocess.Popen = _SkrivenPopen

PORT = 47813
RUN_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"

STARTUP_DIR = os.path.join(os.environ.get("APPDATA", ""), "Microsoft", "Windows", "Start Menu", "Programs", "Startup")

def _startup_stavke():
    """Datoteke u Startup folderu koje pokreću Jarvisa (po nazivu ili po sadržaju prečice)."""
    out = []
    try:
        for f in os.listdir(STARTUP_DIR):
            pth = os.path.join(STARTUP_DIR, f); low = f.lower()
            if not os.path.isfile(pth): continue
            hit = low.startswith("jarvis")
            if not hit and low.endswith((".lnk", ".vbs", ".bat", ".cmd")):
                try:
                    with open(pth, "rb") as fh: d = fh.read(200000)
                except Exception:
                    d = b""
                hit = (b"jarvis" in d.lower() or "jarvis" in d.decode("utf-16-le", "ignore").lower()
                       or "jarvis" in d[1:].decode("utf-16-le", "ignore").lower())
            if hit: out.append(pth)
    except Exception:
        pass
    return out

def _run_stavke():
    """Imena vrijednosti u registru (Run) koje pokreću Jarvisa."""
    imena = []
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY) as k:
            i = 0
            while True:
                try: n, v, _ = winreg.EnumValue(k, i)
                except OSError: break
                i += 1
                if "jarvis" in n.lower() or "jarvis" in str(v).lower(): imena.append(n)
    except Exception:
        pass
    return imena

def pokretanje_ukljuceno():
    return bool(_run_stavke() or _startup_stavke())

def postavi_pokretanje(on):
    """Uključuje/isključuje pokretanje s Windowsom na SVIM mjestima (registar + Startup folder)."""
    import winreg
    for pth in _startup_stavke():                       # stare prečice uvijek uklanjamo (da ne bude dvostruko)
        try: os.remove(pth)
        except Exception: pass
    with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY, 0, winreg.KEY_SET_VALUE) as k:
        for n in _run_stavke():
            try: winreg.DeleteValue(k, n)
            except Exception: pass
        if on:
            if FROZEN:
                naredba = '"%s" --pozadina' % sys.executable
            else:
                pw = sys.executable
                if os.path.basename(pw).lower() == "python.exe":
                    pw = os.path.join(os.path.dirname(pw), "pythonw.exe")
                naredba = '"%s" "%s" --pozadina' % (pw, os.path.abspath(__file__))
            winreg.SetValueEx(k, "Jarvis", 0, winreg.REG_SZ, naredba)

def drzi_instancu():
    """Dozvoljava samo jednu instancu. Vraća (server, vec_radi)."""
    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        if hasattr(socket, "SO_EXCLUSIVEADDRUSE"):
            srv.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        srv.bind(("127.0.0.1", PORT)); srv.listen(2)
        return srv, False
    except OSError:
        try:
            c = socket.create_connection(("127.0.0.1", PORT), timeout=2); c.sendall(b"show"); c.close()
            return None, True              # Jarvis već radi: samo ga pokaži
        except Exception:
            return None, False             # port blokiran, ali Jarvisa nema: nastavi bez zaključavanja

_SRV, _VEC_RADI = drzi_instancu()
if _VEC_RADI and "--debug" not in sys.argv:
    sys.exit(0)

import tkinter as tk
from tkinter import font as tkfont

POZADINA = "--pozadina" in sys.argv
WAV = res("arc_reaktor.wav")
WAV_OFF = res("arc_ugasen.wav")
FLAG = os.path.join(DATA, "jarvis_slusanje_flag.txt")
DNEVNI_LIMIT = 100            # kapacitet "baterije" u jedinicama (običan odgovor = 2, alat +2, slika ekrana +6); mijenja se u jarvis_postavke.json: "kapacitet"
HIST = os.path.join(DATA, "jarvis_historija.json"); HIST_MAX = 300
PAMCENJE = os.path.join(DATA, "jarvis_pamcenje.json")
KLJUC = os.path.join(DATA, "kljuc.txt")

def ucitaj_json(pth, default):
    try:
        with open(pth, encoding="utf-8") as f: return json.load(f)
    except Exception:
        return default

def spremi_json(pth, data):
    try:
        with open(pth, "w", encoding="utf-8") as f: json.dump(data, f, ensure_ascii=False)
    except Exception:
        pass
POSTAVKE = os.path.join(DATA, "jarvis_postavke.json")

def prijavi_gresku(txt, prikazi=True):
    try:
        with open(os.path.join(DATA, "jarvis_error.txt"), "a", encoding="utf-8") as f:
            f.write(time.strftime("%d.%m.%Y %H:%M:%S") + "\n" + txt + "\n\n")
    except Exception:
        pass
    if prikazi:
        if "--debug" in sys.argv: print(txt)
        try:
            from tkinter import messagebox
            r = tk.Tk(); r.withdraw()
            messagebox.showerror("Jarvis", "Jarvis se nije mogao pokrenuti.\n\n" + txt[-600:] +
                                 "\n\n(Isto je upisano u jarvis_error.txt)")
        except Exception:
            pass

try:
    import jarvis                              # alati, ključ, modeli
except BaseException:
    prijavi_gresku(traceback.format_exc() or "Greška pri učitavanju jarvis.py")
    sys.exit(1)

def mk_tema(primary, accent, glow, bg="#04070c"):
    """Pravi cijelu paletu iz glavne boje, akcenta i boje sjaja (hover)."""
    ink = mix(primary, "#ffffff", 0.82)
    return dict(bg=bg, panel=mix(bg, primary, 0.07), ink=ink, mute=mix(bg, ink, 0.45), cy=primary,
                cy2=mix(bg, primary, 0.5), gold=accent, red="#ff3b53", line=mix(bg, primary, 0.2),
                glow=glow, glow_hi=mix(glow, "#ffffff", 0.55), me=mix(bg, primary, 0.14))

TEME = {
    "iron":   dict(primary="#3fe0ff", accent="#f5b83d", glow="#2f7dff", bg="#04070c"),
    "spider": dict(primary="#ff4141", accent="#4a8cff", glow="#3b6dff", bg="#07050a"),
    "batman": dict(primary="#f5c518", accent="#aab4be", glow="#ffd84a", bg="#050505"),
    "matrix": dict(primary="#2bff7a", accent="#c8ff7a", glow="#12b85a", bg="#020a04"),
}

_docs = os.path.join(os.path.expanduser("~"), "Documents")
DOK_DIR = os.path.join(_docs if os.path.isdir(_docs) else os.path.expanduser("~"), "Jarvis dokumenti")

def sigurno_ime(naziv):
    n = re.sub(r'[\\/:*?"<>|\r\n]+', " ", str(naziv or "")).strip()[:60]
    return n or "Jarvis dokument"

def napravi_docx(path, tekst):
    """Pravi običan Word dokument (.docx) bez dodatnih paketa. '# ' i '## ' su naslovi, '- ' su tačke."""
    import zipfile
    from xml.sax.saxutils import escape
    redovi = str(tekst).replace("\r\n", "\n").replace("\r", "\n").split("\n")
    tijelo = []
    for r in redovi:
        r = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "", r)
        rpr = ""
        if r.startswith("## "): r, rpr = r[3:], '<w:rPr><w:b/><w:sz w:val="28"/></w:rPr>'
        elif r.startswith("# "): r, rpr = r[2:], '<w:rPr><w:b/><w:sz w:val="34"/></w:rPr>'
        elif r.startswith("- ") or r.startswith("* "): r = "\u2022 " + r[2:]
        tijelo.append('<w:p><w:r>%s<w:t xml:space="preserve">%s</w:t></w:r></w:p>' % (rpr, escape(r)))
    dokument = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>' + "".join(tijelo) +
                '<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1417" w:right="1417" w:bottom="1417" '
                'w:left="1417" w:header="708" w:footer="708" w:gutter="0"/></w:sectPr></w:body></w:document>')
    tipovi = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
              '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
              '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
              '<Default Extension="xml" ContentType="application/xml"/>'
              '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>'
              '</Types>')
    veze = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>'
            '</Relationships>')
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", tipovi); z.writestr("_rels/.rels", veze); z.writestr("word/document.xml", dokument)

DA_RIJECI = {"da", "može", "moze", "naravno", "okej", "ok", "slobodno", "otvori", "aha"}
NE_RIJECI = {"ne", "nemoj", "stani", "odustani", "ništa", "nista"}

def citaj_kljuc():
    try:
        with open(KLJUC, encoding="utf-8-sig") as f:
            k = f.read().strip()
        if k: return k
    except Exception:
        pass
    return (os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY") or "").strip()

def mk_path(pts):
    cum = [0.0]
    for a, b in zip(pts, pts[1:]): cum.append(cum[-1] + math.hypot(b[0] - a[0], b[1] - a[1]))
    ys = [p[1] for p in pts]
    return dict(pts=pts, cum=cum, L=cum[-1], y0=min(ys), y1=max(ys))

def tacka_na(path, d):
    """Tačka na putanji na udaljenosti d (px od početka)."""
    cum, pts = path["cum"], path["pts"]
    d = max(0.0, min(d, path["L"]))
    i = bisect.bisect_right(cum, d) - 1
    if i >= len(pts) - 1: return pts[-1]
    seg = cum[i + 1] - cum[i]; t = (d - cum[i]) / seg if seg > 0 else 0.0
    return (pts[i][0] + (pts[i + 1][0] - pts[i][0]) * t, pts[i][1] + (pts[i + 1][1] - pts[i][1]) * t)

def kontrast(h):
    r, g, b = [int(h[i:i + 2], 16) for i in (1, 3, 5)]
    return "#000000" if (0.299 * r + 0.587 * g + 0.114 * b) > 150 else "#ffffff"

FONT, FONTB = ("Consolas", 11), ("Consolas", 11, "bold")
IZLAZ = ("kraj", "izlaz", "ugasi se", "exit", "quit")
SAPI = ("Add-Type -AssemblyName System.Speech; $s=New-Object System.Speech.Synthesis.SpeechSynthesizer; "
        "$v=$s.GetInstalledVoices()|Where-Object{$_.VoiceInfo.Culture.Name -match '^(bs|hr|sr)'}|Select-Object -First 1; "
        "if($v){$s.SelectVoice($v.VoiceInfo.Name)}; $s.Speak($env:JT)")
PRAZNA = "Nemam baterije."


EKRAN_RIJECI = ("ekran", "monitor", "slik", "slici", "screen", "screenshot", "skrin", "snimak", "displej", "display",
                "radnu površ", "radna površ", "desktop", "šta vidiš", "sta vidis", "što vidiš", "vidiš li",
                "pogledaj ovo", "pogledaj šta", "pogledaj sta")

def trazi_ekran(t):
    tl = t.lower()
    return any(w in tl for w in EKRAN_RIJECI)

def snimi_ekran():
    """Slika glavnog ekrana (JPEG, smanjena radi brzine). Vraća bajtove ili None."""
    try:
        import io
        from PIL import ImageGrab
        im = ImageGrab.grab().convert("RGB")
        if im.width > 1600:
            im = im.resize((1600, int(im.height * 1600 / im.width)))
        b = io.BytesIO(); im.save(b, "JPEG", quality=82)
        return b.getvalue()
    except Exception:
        return None


def pac_datum():
    """Datum po pacifičkom vremenu (tada Google resetuje dnevne kvote)."""
    try:
        from zoneinfo import ZoneInfo
        from datetime import datetime
        return datetime.now(ZoneInfo("America/Los_Angeles")).strftime("%Y-%m-%d")
    except Exception:
        return time.strftime("%Y-%m-%d", time.gmtime(time.time() - 8 * 3600))


def mix(a, b, t):
    pa = [int(a[i:i + 2], 16) for i in (1, 3, 5)]; pb = [int(b[i:i + 2], 16) for i in (1, 3, 5)]
    return "#%02x%02x%02x" % tuple(int(x + (y - x) * max(0, min(1, t))) for x, y in zip(pa, pb))


def nadji_jarvisa(t):
    """Prepoznaje 'Jarvis' i kad ga Google čuje kao đarvis, džarvis, djarvis, žarvis...
    Vraća (nađeno, ostatak_rečenice)."""
    for m in re.finditer(r"\w+", t):
        w = m.group(0).lower()
        n = w.replace("đ", "dj").replace("dž", "j").replace("ž", "j").replace("č", "c").replace("ć", "c")
        if re.fullmatch(r"(dj|j|g|y|d|z|c|h)?arvi[sz]\w{0,3}", n) or difflib.SequenceMatcher(None, n, "jarvis").ratio() >= 0.75:
            return True, (t[:m.start()] + " " + t[m.end():]).strip(" ,.!?")
    return False, t


class HudButton(tk.Canvas):
    """Dugme sa zakošenim uglovima; na prelazak miša 'poplavi' (svijetli plavo), na klik zatreperi."""
    def __init__(s, parent, app, text, cmd, w, kind="toggle"):
        s.f = tkfont.Font(family="Consolas", size=10, weight="bold")
        s.app, s.cmd, s.kind, s.text, s.w, s.h = app, cmd, kind, text, w, 34
        super().__init__(parent, width=w, height=s.h, highlightthickness=0, bd=0, cursor="hand2")
        s.t, s.target, s.press, s.on, s.enabled = 0.0, 0.0, 0.0, False, True
        s.bind("<Enter>", lambda e: s._to(1.0)); s.bind("<Leave>", lambda e: s._to(0.0))
        s.bind("<ButtonPress-1>", lambda e: s._down()); s.bind("<ButtonRelease-1>", s._up)
        s._job = None
        s.redraw()

    def set(s, text=None, on=None, enabled=None):
        if text is not None: s.text = text
        if on is not None: s.on = on
        if enabled is not None:
            s.enabled = enabled; s.configure(cursor="hand2" if enabled else "arrow")
        s.redraw()

    def _to(s, v):
        s.target = v if s.enabled else 0.0
        if s._job is None: s._step()

    def _step(s):
        s.t += (s.target - s.t) * 0.35; s.press *= 0.7
        if abs(s.target - s.t) < 0.02: s.t = s.target
        if s.press < 0.03: s.press = 0.0
        s.redraw()
        if s.t != s.target or s.press:
            s._job = s.after(16, s._step)
        else:
            s._job = None

    def _down(s):
        if s.enabled:
            s.press = 1.0
            if s._job is None: s._step()

    def _up(s, e):
        if s.enabled and 0 <= e.x <= s.w and 0 <= e.y <= s.h:
            s.app.ui_zvuk("klik"); s.cmd()

    def redraw(s):
        C = s.app.C; w, h, c = s.w, s.h, 9
        s.configure(bg=C["bg"]); s.delete("all")
        full = s.on or s.kind == "main"
        base, fg = (C["cy"], C["bg"]) if full else (C["panel"], C["ink"])
        if not s.enabled: base, fg = C["panel"], C["mute"]
        t = s.t
        fill = mix(base, C["glow"], t * 0.85 + s.press * 0.15)
        edge = mix(C["cy2"], C["glow_hi"], t)
        txt = mix(fg, "#ffffff", t) if full else mix(fg, C["glow_hi"], t)
        pts = [c, 1, w - 1, 1, w - 1, h - c, w - c, h - 1, 1, h - 1, 1, c]
        if t > 0.02:                                              # sjaj oko dugmeta
            s.create_polygon(pts, fill="", outline=mix(C["bg"], C["glow"], t * 0.7), width=4)
        s.create_polygon(pts, fill=fill, outline=edge, width=2 if t > 0.5 else 1)
        s.create_text(w / 2, h / 2 + (1 if s.press else 0), text=s.text, fill=txt, font=s.f)


class HudSwitch(tk.Canvas):
    """Red u meniju: naziv lijevo, prekidač desno. Na prelazak miša poplavi, klik prebacuje."""
    def __init__(s, parent, app, text, getter, cmd, enabled=lambda: True, w=360):
        s.f = tkfont.Font(family="Consolas", size=10, weight="bold")
        s.app, s.text, s.getter, s.cmd, s.en, s.w, s.h = app, text, getter, cmd, enabled, w, 32
        super().__init__(parent, width=w, height=s.h, highlightthickness=0, bd=0, cursor="hand2")
        s.t, s.target, s.k, s._job = 0.0, 0.0, 1.0 if getter() else 0.0, None
        s.bind("<Enter>", lambda e: s._to(1.0)); s.bind("<Leave>", lambda e: s._to(0.0))
        s.bind("<ButtonRelease-1>", s._up)
        s.redraw()

    def _to(s, v):
        s.target = v if s.en() else 0.0
        if s._job is None: s._step()

    def refresh(s):
        s.configure(cursor="hand2" if s.en() else "arrow")
        if s._job is None: s._step()

    def _step(s):
        goal = 1.0 if s.getter() else 0.0
        s.t += (s.target - s.t) * 0.35; s.k += (goal - s.k) * 0.4
        if abs(s.target - s.t) < 0.02: s.t = s.target
        if abs(goal - s.k) < 0.03: s.k = goal
        s.redraw()
        if s.t != s.target or s.k != goal:
            s._job = s.after(16, s._step)
        else:
            s._job = None

    def _up(s, e):
        if s.en() and 0 <= e.x <= s.w and 0 <= e.y <= s.h:
            s.cmd(); s.refresh()

    def redraw(s):
        C = s.app.C; w, h, c = s.w, s.h, 8
        on, en = s.getter(), s.en()
        s.configure(bg=C["bg"]); s.delete("all")
        pts = [c, 1, w - 1, 1, w - 1, h - c, w - c, h - 1, 1, h - 1, 1, c]
        if s.t > 0.02:
            s.create_polygon(pts, fill="", outline=mix(C["bg"], C["glow"], s.t * 0.7), width=4)
        s.create_polygon(pts, fill=mix(C["panel"], C["glow"], s.t * 0.55), outline=mix(C["cy2"], C["glow_hi"], s.t),
                         width=2 if s.t > 0.5 else 1)
        tc = C["ink"] if en else C["mute"]
        s.create_text(14, h / 2, text=s.text, anchor="w", fill=mix(tc, "#ffffff", s.t * 0.5), font=s.f)
        tw, th = 44, 18; x1 = w - 16 - tw; y1 = (h - th) / 2
        track = mix(C["bg"], C["cy"] if en else C["mute"], 0.18 + 0.62 * s.k)
        s.create_oval(x1, y1, x1 + th, y1 + th, fill=track, outline="")
        s.create_oval(x1 + tw - th, y1, x1 + tw, y1 + th, fill=track, outline="")
        s.create_rectangle(x1 + th / 2, y1, x1 + tw - th / 2, y1 + th, fill=track, outline="")
        kx = x1 + 2 + (tw - th) * s.k
        s.create_oval(kx, y1 + 2, kx + th - 4, y1 + th - 2, fill=C["bg"] if on else C["ink"], outline="")
        lab = "TIH" if (not en and s.app.tihi) else ("ON" if on else "OFF")
        s.create_text(x1 - 10, h / 2, text=lab, anchor="e", fill=C["cy"] if on else C["mute"], font=s.f)


VOICES = {"vesna": "bs-BA-VesnaNeural", "goran": "bs-BA-GoranNeural"}


class Natpis:
    """Tekst nacrtan na platnu (umjesto tk.Label), da pozadina ostane vidljiva iza njega."""
    def __init__(s, platno, x, y, anchor, font, tekst=""):
        s.c = platno
        s.id = platno.create_text(x, y, anchor=anchor, font=font, text=tekst, fill="#ffffff", tags="ui")

    def configure(s, **kw):
        if "text" in kw: s.c.itemconfigure(s.id, text=kw["text"])
        if "fg" in kw: s.c.itemconfigure(s.id, fill=kw["fg"])
        if "font" in kw: s.c.itemconfigure(s.id, font=kw["font"])

    def bind(s, seq, fn, add=None):
        s.c.tag_bind(s.id, seq, fn, add)

    def moveto(s, x, y):
        s.c.coords(s.id, x, y)


class Pomak:
    """Crta na platnu s pomakom (ox, oy) i zajedničkom oznakom; koordinate se zadaju lokalno."""
    def __init__(s, platno, ox, oy, tag):
        s.c, s.ox, s.oy, s.tag = platno, ox, oy, tag

    def _k(s, co):
        return [v + (s.ox if i % 2 == 0 else s.oy) for i, v in enumerate(co)]

    def _kw(s, kw):
        kw = dict(kw); t = kw.pop("tags", ())
        kw["tags"] = (s.tag,) + ((t,) if isinstance(t, str) else tuple(t)); return kw

    def create_oval(s, *co, **kw): return s.c.create_oval(*s._k(co), **s._kw(kw))
    def create_arc(s, *co, **kw): return s.c.create_arc(*s._k(co), **s._kw(kw))
    def create_line(s, *co, **kw): return s.c.create_line(*s._k(co), **s._kw(kw))
    def create_rectangle(s, *co, **kw): return s.c.create_rectangle(*s._k(co), **s._kw(kw))
    def create_polygon(s, *co, **kw): return s.c.create_polygon(*s._k(co), **s._kw(kw))
    def create_text(s, *co, **kw): return s.c.create_text(*s._k(co), **s._kw(kw))


class UnosPolje(tk.Text):
    """Višelinijsko polje: prelama dugačak tekst i raste do 6 redova. Enter šalje, Shift+Enter je novi red."""
    MAXR = 6

    def __init__(s, parent, na_enter):
        s.f_unos = tkfont.Font(family="Consolas", size=12)
        super().__init__(parent, wrap="word", width=1, height=1, relief="flat", font=s.f_unos,
                         highlightthickness=1, padx=8, pady=6, bd=0, undo=True)
        s.na_enter = na_enter
        s.bind("<Return>", s._enter)
        s.bind("<Shift-Return>", lambda e: s.after_idle(s.prilagodi))
        s.bind("<KeyPress>", lambda e: s.after_idle(s.prilagodi))
        s.bind("<KeyRelease>", lambda e: s.prilagodi())
        s.bind("<<Paste>>", lambda e: s.after(15, s.prilagodi))
        s.bind("<<Cut>>", lambda e: s.after(15, s.prilagodi))
        s.bind("<Configure>", lambda e: s.after_idle(s.prilagodi))

    def _enter(s, e):
        s.na_enter(); return "break"

    def tekst(s):
        return s.get("1.0", "end-1c")

    def isprazni(s):
        s.delete("1.0", "end"); s.prilagodi()

    def prilagodi(s):
        txt = s.tekst()
        if not txt:
            s.configure(height=1); return
        n = None
        try:
            r = s.count("1.0", "end-1c", "displaylines")
            val = r[0] if isinstance(r, (tuple, list)) else r
            if val is not None:
                n = int(val) + (1 if txt.endswith("\n") else 0)
        except Exception:
            n = None
        if not n or n < 1:
            w = max(80, s.winfo_width() - 20)
            cw = max(1, s.f_unos.measure("M"))
            chars_per_line = max(1, w // cw)
            n = sum(max(1, math.ceil(len(line) / chars_per_line)) for line in txt.split("\n"))
        s.configure(height=max(1, min(s.MAXR, n)))


class Govor:
    """Čita odgovore naglas: prirodni bosanski glas (Vesna/Goran, online) ili Windows glas (offline)."""
    def __init__(s, na_pocetku, na_kraju):
        s.q = queue.Queue(); s.busy = False; s.proc = None; s.playing = False
        s.tip = "windows"; s.alias = "jv%d" % os.getpid()
        s.na_pocetku, s.na_kraju = na_pocetku, na_kraju
        threading.Thread(target=s._run, daemon=True).start()

    def say(s, t):
        t = t.strip()
        if t:
            s.busy = True; s.q.put(t)

    def _mci(s):
        import ctypes
        return ctypes.windll.winmm.mciSendStringW

    def stop(s):
        try:
            while True: s.q.get_nowait()
        except queue.Empty:
            pass
        if s.proc and s.proc.poll() is None:
            try: s.proc.terminate()
            except Exception: pass
        if s.playing:
            try:
                m = s._mci(); m("stop %s" % s.alias, None, 0, 0); m("close %s" % s.alias, None, 0, 0)
            except Exception:
                pass
        s.busy = False

    def _edge(s, t):
        """Microsoft neural bosanski glas. Vraća True ako je izgovoreno, False ako treba Windows glas."""
        try:
            import asyncio, tempfile, edge_tts
            path = os.path.join(tempfile.gettempdir(), "jarvis_%d.mp3" % os.getpid())
            async def sint():
                await asyncio.wait_for(edge_tts.Communicate(t, VOICES[s.tip]).save(path), 20)
            asyncio.run(sint())
            if not os.path.exists(path) or os.path.getsize(path) < 500:
                return False
            m = s._mci()
            m("close %s" % s.alias, None, 0, 0)
            if m('open "%s" type mpegvideo alias %s' % (path, s.alias), None, 0, 0) != 0:
                return False
            s.playing = True
            m("play %s wait" % s.alias, None, 0, 0)
            m("close %s" % s.alias, None, 0, 0)
            s.playing = False
            try: os.remove(path)
            except Exception: pass
            return True
        except Exception:
            s.playing = False
            return False

    def _windows(s, t):
        try:
            env = dict(os.environ, JT=t)
            s.proc = subprocess.Popen(["powershell", "-NoProfile", "-Command", SAPI], env=env,
                                      stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                                      stderr=subprocess.DEVNULL, creationflags=0x08000000)
            s.proc.wait()
        except Exception:
            pass
        s.proc = None

    def _run(s):
        while True:
            t = s.q.get()
            s.na_pocetku()
            if not (s.tip in VOICES and s._edge(t)):
                s._windows(t)
            if s.q.empty():
                s.busy = False; s.na_kraju()


class App:
    SZ = 200

    def __init__(s):
        cfg = {}
        try:
            with open(POSTAVKE, encoding="utf-8") as f: cfg = json.load(f)
        except Exception:
            pass
        s.glas, s.efekat = cfg.get("glas", True), cfg.get("efekat", True)
        s.tihi, s.stalno = cfg.get("tihi", False), cfg.get("stalno", True)
        s.start_on = pokretanje_ukljuceno()
        s.uvod = cfg.get("uvod", True); s.film_on = False; s.film_t0 = 0.0
        s.tema = cfg.get("tema", "iron")
        s.bg_key, s.bg_y0, s.bg, s.bg_sh = None, 0.0, None, 0.0
        s.pita, s.potvrda_cekanje = None, 40
        s.cust_p, s.cust_a = cfg.get("cust_p", "#b388ff"), cfg.get("cust_a", "#ffd166")
        try:
            s.edge_ima = importlib.util.find_spec("edge_tts") is not None
        except Exception:
            s.edge_ima = sys.modules.get("edge_tts") is not None
        s.glas_tip = cfg.get("glas_tip", "vesna" if s.edge_ima else "windows")
        if s.glas_tip in VOICES and not s.edge_ima: s.glas_tip = "windows"
        s.pao = False
        if os.path.exists(FLAG):                                    # prošli put se slušanje srušilo
            s.pao, s.stalno = True, False
            try: os.remove(FLAG)
            except Exception: pass
            cfg["stalno"] = False
            try:
                with open(POSTAVKE, "w", encoding="utf-8") as f: json.dump(cfg, f)
            except Exception: pass
        s.limit = max(20, int(cfg.get("kapacitet", DNEVNI_LIMIT)))
        s.dan, s.iskoristeno = cfg.get("dan", pac_datum()), int(cfg.get("iskoristeno", 0))
        if cfg.get("bat_v") != 2: s.iskoristeno = 0                   # nova, brža skala baterije
        s.hist_on = cfg.get("hist", True)
        s.auto_azur = cfg.get("azur", True); s.azur_spreman = 0
        s.prazna = bool(cfg.get("prazna", False)); s.gasi = False; s.gasi_t0 = 0.0; s.zadnji_dan = 0.0
        s.bat_provjeri_dan()
        s.C = s.boje()

        try:                                                     # vlastita ikona u taskbaru (ne Python)
            import ctypes
            if not FROZEN: ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("Naze.Jarvis.MK2")
        except Exception:
            pass
        s.root = tk.Tk()
        s.root.title("J.A.R.V.I.S. MK II"); s.root.minsize(440, 520)
        s.root.geometry("500x%d+60+10" % min(760, s.root.winfo_screenheight() - 110))
        ico = res("jarvis.ico")
        if os.path.exists(ico):
            try:
                s.root.iconbitmap(default=ico); s.root.iconbitmap(ico)
            except Exception:
                pass
        s.ui_q = queue.Queue()
        s.state, s.phase, s.busy = "idle", 0.0, False
        s.hidden, s.otvoren_glasom, s.zadnja = False, False, time.time()
        s.expect, s.expect_do, s.zvuk_do, s.slusa = False, 0.0, 0.0, False
        s.stop_bg, s.msgs, s.stick, s.panel_on = None, [], True, False
        s.hist = ucitaj_json(HIST, []) if s.hist_on else []
        s.hist = [m for m in s.hist if isinstance(m, dict) and m.get("u") in ("me", "ai") and m.get("t")][-HIST_MAX:] if isinstance(s.hist, list) else []
        s.msgs = [(m["u"], m["t"]) for m in s.hist]
        s.tray = None
        s.mi = 0; s.chat = None; s.klijent = None
        s.lh = tkfont.Font(family="Consolas", size=11, weight="bold").metrics("linespace")
        s.govor = Govor(lambda: s.ui(lambda: s.set_state("speak")), lambda: s.ui(lambda: s.set_state("idle")))
        s.govor.tip = s.glas_tip
        jarvis.reci = lambda t: s.ui(lambda: s.stigao_odgovor(t))        # podsjetnici iz jarvis.py

        # donji dio se pakira prvi, da se na malom ekranu uvijek vidi
        s.row = tk.Frame(s.root); s.row.pack(side="bottom", fill="x", padx=14, pady=(4, 14))
        s.TOP_PUNO, s.TOP_MALO = 298, 92
        s.top = tk.Canvas(s.root, height=s.TOP_PUNO, highlightthickness=0); s.top.pack(side="top", fill="x", padx=6)
        s.f_naslov = tkfont.Font(family="Consolas", size=16, weight="bold")
        s.title = Natpis(s.top, 16, 26, "w", ("Consolas", 16, "bold"), "J.A.R.V.I.S")
        s.mk = Natpis(s.top, 190, 31, "w", ("Consolas", 10, "bold"), "MK II")
        s.btn_opc = HudButton(s.top, s, "OPCIJE", s.toggle_panel, 88)
        s.opc_id = s.top.create_window(480, 12, window=s.btn_opc, anchor="ne")
        s.status = Natpis(s.top, 16, 58, "w", ("Consolas", 10))
        s.clock = Natpis(s.top, 480, 58, "e", ("Consolas", 10))
        s.cuo = Natpis(s.top, 16, 76, "w", ("Consolas", 9))
        s.top_cx, s.top_cy = 250, 84 + s.SZ / 2
        s.top.bind("<Configure>", lambda e: s.root.after_idle(s.top_raspored))
        s.chat_c = tk.Canvas(s.root, highlightthickness=0, yscrollincrement=28)
        s.chat_c.pack(side="top", fill="both", expand=True, padx=6)
        s.chat_c.bind("<Configure>", lambda e: s.root.after_idle(s.layout))
        s.intro_c = tk.Canvas(s.root, highlightthickness=0)
        s.root.bind_all("<MouseWheel>", s.kolo)

        s.entry = UnosPolje(s.row, s.salji)
        s.entry.pack(side="left", fill="x", expand=True)
        s.btn_ekran = HudButton(s.row, s, "EKRAN", s.klik_ekran, 84, "main"); s.btn_ekran.pack(side="left", padx=(8, 0), anchor="s")
        s.btn_mic = HudButton(s.row, s, "MIKROFON", s.mic_once, 118, "main"); s.btn_mic.pack(side="left", padx=(6, 0), anchor="s")
        # traka s pitanjem "Mogu li otvoriti ...?" (DA / NE), prikazuje se iznad polja za pisanje
        s.pitanje_f = tk.Frame(s.root)
        s.pitanje_l = tk.Label(s.pitanje_f, font=("Consolas", 10, "bold"), anchor="w", justify="left", wraplength=290)
        s.pitanje_l.pack(side="left", fill="x", expand=True)
        s.b_ne = HudButton(s.pitanje_f, s, "NE", lambda: s.odgovori(False), 70); s.b_ne.pack(side="right")
        s.b_da = HudButton(s.pitanje_f, s, "DA", lambda: s.odgovori(True), 70, "main"); s.b_da.pack(side="right", padx=(0, 8))
        s.root.bind_all("<Key>", lambda e: s.korisnik()); s.root.bind_all("<Button-1>", lambda e: s.korisnik())
        s.root.bind("<Escape>", lambda e: s.odgovori(False) if s.pita else (s.toggle_panel() if s.panel_on else s.sakrij()))

        # meni s opcijama (preko razgovora): ZVUK / TEMA / VIŠE
        s.panel = tk.Frame(s.root)
        s.panel_c = tk.Canvas(s.panel, highlightthickness=0, bd=0)
        s.panel_c.place(x=0, y=0, relwidth=1, relheight=1)
        s.p_title = tk.Label(s.panel, text="O P C I J E", font=("Consolas", 13, "bold")); s.p_title.pack(pady=(10, 6))
        s.tabbar = tk.Frame(s.panel); s.tabbar.pack()
        s.tab, s.tab_btn = "zvuk", {}
        for i, (kljuc, naziv) in enumerate((("zvuk", "ZVUK"), ("tema", "TEMA"), ("vise", "VIŠE"))):
            b = HudButton(s.tabbar, s, naziv, lambda k=kljuc: s.pokazi_tab(k), 114)
            b.pack(side="left", padx=(0 if i == 0 else 9, 0)); s.tab_btn[kljuc] = b
        s.b_zatvori = HudButton(s.panel, s, "ZATVORI OPCIJE", s.toggle_panel, 360, "main")
        s.b_zatvori.pack(side="bottom", pady=(6, 12))
        s.pc = tk.Frame(s.panel); s.pc.pack(pady=(8, 0))
        s.tab_f = {k: tk.Frame(s.pc) for k in ("zvuk", "tema", "vise")}
        s.p_sec = []
        def sekcija(roditelj, tekst):
            l = tk.Label(roditelj, text=tekst, font=("Consolas", 9, "bold"), anchor="w"); l.pack(fill="x", pady=(8, 3))
            s.p_sec.append(l)
        # --- ZVUK ---
        z = s.tab_f["zvuk"]
        s.sw_glas = HudSwitch(z, s, "GLAS (Jarvis govori)", lambda: s.glas and not s.tihi, s.toggle_glas, lambda: not s.tihi)
        s.sw_tihi = HudSwitch(z, s, "TIHI MOD", lambda: s.tihi, s.toggle_tihi)
        s.sw_stalno = HudSwitch(z, s, "STALNO SLUŠANJE „JARVIS“", lambda: s.stalno, s.toggle_stalno)
        for w in (s.sw_glas, s.sw_tihi, s.sw_stalno): w.pack(pady=3)
        s.b_vrsta = HudButton(z, s, "", s.ciklus_glasa, 360); s.b_vrsta.pack(pady=3)
        s.sw_efekat = HudSwitch(z, s, "ZVUČNI EFEKTI", lambda: s.efekat and not s.tihi, s.toggle_efekat, lambda: not s.tihi)
        s.sw_efekat.pack(pady=3)
        # --- TEMA ---
        t = s.tab_f["tema"]
        sekcija(t, "■ IZABERI TEMU")
        red1 = tk.Frame(t); red1.pack(); red2 = tk.Frame(t); red2.pack(pady=(8, 0))
        s.b_tema = {}
        for i, (k, naziv) in enumerate((("iron", "IRON MAN"), ("spider", "SPIDER-MAN"), ("batman", "BATMAN"))):
            b = HudButton(red1, s, naziv, lambda n=k: s.postavi_temu(n), 114)
            b.pack(side="left", padx=(0 if i == 0 else 9, 0)); s.b_tema[k] = b
        for i, (k, naziv) in enumerate((("matrix", "MATRIX"), ("custom", "CUSTOM"))):
            b = HudButton(red2, s, naziv, lambda n=k: s.postavi_temu(n), 175)
            b.pack(side="left", padx=(0 if i == 0 else 10, 0)); s.b_tema[k] = b
        s.custom_f = tk.Frame(t)                                    # prikazuje se samo kad je izabran CUSTOM
        sekcija(s.custom_f, "■ TVOJE BOJE")
        red3 = tk.Frame(s.custom_f); red3.pack()
        s.b_bp = HudButton(red3, s, "GLAVNA BOJA", lambda: s.izaberi_boju("p"), 175); s.b_bp.pack(side="left")
        s.b_ba = HudButton(red3, s, "AKCENT BOJA", lambda: s.izaberi_boju("a"), 175); s.b_ba.pack(side="left", padx=(10, 0))
        s.tema_prev = tk.Canvas(s.custom_f, width=360, height=26, highlightthickness=0); s.tema_prev.pack(pady=(8, 0))
        # --- VIŠE ---
        v = s.tab_f["vise"]
        s.sw_uvod = HudSwitch(v, s, "FILMSKO POKRETANJE", lambda: s.uvod, s.toggle_uvod)
        s.sw_start = HudSwitch(v, s, "PALI SE S WINDOWSOM", lambda: s.start_on, s.toggle_start)
        s.sw_azur = HudSwitch(v, s, "AUTOMATSKO AŽURIRANJE", lambda: s.auto_azur, s.toggle_azur)
        for w in (s.sw_uvod, s.sw_start, s.sw_azur): w.pack(pady=2)
        s.p_az = tk.Frame(v); s.p_az.pack(fill="x", pady=(6, 0))
        s.b_azur_p = HudButton(s.p_az, s, "PROVJERI AŽURIRANJE", lambda: s.provjeri_azuriranje(True), 175); s.b_azur_p.pack(side="left")
        s.lbl_verzija = tk.Label(s.p_az, text="verzija %s · build %d" % (VERZIJA, BUILD), font=("Consolas", 9))
        s.lbl_verzija.pack(side="right")
        s.lbl_verzija.bind("<Double-Button-1>", lambda e: s.postavi_adresu())      # skriveno: adresa za ažuriranje
        sekcija(v, "■ PODACI")
        s.sw_hist = HudSwitch(v, s, "ČUVAJ HISTORIJU RAZGOVORA", lambda: s.hist_on, s.toggle_hist); s.sw_hist.pack(pady=2)
        s.p_mem = tk.Frame(v); s.p_mem.pack(fill="x", pady=(6, 0))
        s.b_mem_p = HudButton(s.p_mem, s, "PAMĆENJE: PRIKAŽI", s.prikazi_pamcenje, 175); s.b_mem_p.pack(side="left")
        s.b_mem_o = HudButton(s.p_mem, s, "PAMĆENJE: OBRIŠI", s.obrisi_pamcenje, 175); s.b_mem_o.pack(side="right")
        s.p_kl = tk.Frame(v); s.p_kl.pack(fill="x", pady=(6, 0))
        s.b_kljuc = HudButton(s.p_kl, s, "API KLJUČ", s.promijeni_kljuc, 175); s.b_kljuc.pack(side="left")
        s.b_azur_u = HudButton(s.p_kl, s, "ADRESA AŽURIRANJA", s.postavi_adresu, 175)     # vidi se samo dok adresa nije podešena
        s.p_act = tk.Frame(v); s.p_act.pack(fill="x", pady=(8, 0))
        s.b_ocisti = HudButton(s.p_act, s, "OČISTI", s.ocisti, 116); s.b_ocisti.pack(side="left")
        s.b_sakrij = HudButton(s.p_act, s, "SAKRIJ", s.sakrij_iz_menija, 116); s.b_sakrij.pack(side="left", padx=6)
        s.b_ugasi = HudButton(s.p_act, s, "UGASI", s.zatvori, 116); s.b_ugasi.pack(side="right")
        s.p_frames = [s.pc, s.tabbar, red1, red2, red3, s.custom_f, s.p_act, s.p_mem, s.p_kl, s.p_az] + list(s.tab_f.values())
        s.tab_f["zvuk"].pack()
        s.entry.focus_set()

        s.apply_theme()
        s.povuci_prozor()
        s.start_ai()
        s.set_state("idle")
        if s.pao:
            s.add("err", "Stalno slušanje se prošli put srušilo, pa sam ga isključio. Možeš ga ponovo uključiti u OPCIJAMA; "
                         "ako opet padne, pošalji mi jarvis_error.txt.")
        s.root.protocol("WM_DELETE_WINDOW", s.sakrij)
        if s.stalno:
            threading.Thread(target=s.start_slusanje, daemon=True).start()
        if POZADINA:
            s.sakrij()
        threading.Thread(target=s.slusaj_instancu, daemon=True).start()
        s.bez_okvira()
        s.root.after(1200, s.start_tray)
        s.root.after(25000, s.azur_ciklus)
        if s.uvod:
            s.root.after(500, s.film_pozadina if POZADINA else s.film_start)
        s.tick()

    # ---------- postavke / tema ----------
    def spremi(s):
        try:
            with open(POSTAVKE, "w", encoding="utf-8") as f:
                json.dump(dict(glas=s.glas, efekat=s.efekat, tihi=s.tihi, stalno=s.stalno, kapacitet=s.limit, bat_v=2, hist=s.hist_on, azur=s.auto_azur, glas_tip=s.glas_tip, uvod=s.uvod, tema=s.tema, cust_p=s.cust_p, cust_a=s.cust_a,
                               dan=s.dan, iskoristeno=s.iskoristeno, prazna=s.prazna), f)
        except Exception:
            pass

    def apply_theme(s):
        C = s.C
        s.root.configure(bg=C["bg"])
        try: s.root.configure(highlightthickness=1, highlightbackground=C["cy2"], highlightcolor=C["cy2"])
        except Exception: pass
        for f in (s.row, s.panel, s.pitanje_f): f.configure(bg=C["bg"])
        s.top.configure(bg=C["bg"])
        s.title.configure(fg=C["cy"]); s.clock.configure(fg=C["mute"])
        s.mk.configure(fg=C["gold"]); s.cuo.configure(fg=C["mute"])
        s.pitanje_l.configure(bg=C["bg"], fg=C["gold"]); s.lbl_verzija.configure(bg=C["bg"], fg=C["mute"])
        s.p_title.configure(bg=C["bg"], fg=C["cy"])
        for f in s.p_frames: f.configure(bg=C["bg"])
        for l in s.p_sec: l.configure(bg=C["bg"], fg=C["gold"])
        s.chat_c.configure(bg=C["bg"]); s.intro_c.configure(bg=C["bg"]); s.panel_c.configure(bg=C["bg"])
        s.bg_key = None
        s.entry.configure(bg=C["panel"], fg=C["ink"], insertbackground=C["cy"],
                          highlightbackground=C["line"], highlightcolor=C["cy"])
        s.refresh_buttons(); s.layout(); s.bat_crtaj()

    def refresh_buttons(s):
        for w in (s.sw_glas, s.sw_efekat, s.sw_tihi, s.sw_stalno, s.sw_uvod, s.sw_start, s.sw_hist, s.sw_azur): w.refresh()
        imena = {"vesna": "VESNA (BOSANSKI, ŽENSKI)", "goran": "GORAN (BOSANSKI, MUŠKI)", "windows": "WINDOWS (OFFLINE)"}
        s.b_vrsta.set(text="VRSTA GLASA: " + imena[s.glas_tip], on=s.glas_tip != "windows", enabled=not s.tihi)
        s.btn_opc.set(on=s.panel_on)
        for b in (s.b_ocisti, s.b_sakrij, s.b_ugasi, s.b_zatvori, s.btn_mic, s.btn_ekran, s.b_bp, s.b_ba, s.b_da, s.b_ne, s.b_mem_p, s.b_mem_o, s.b_kljuc, s.b_azur_u, s.b_azur_p): b.set()
        for k, b in s.tab_btn.items(): b.set(on=(k == s.tab))
        for k, b in s.b_tema.items(): b.set(on=(k == s.tema))
        if s.tema == "custom": s.custom_f.pack(pady=(10, 0))      # TVOJE BOJE samo uz temu CUSTOM
        else: s.custom_f.pack_forget()
        if azur_url(): s.b_azur_u.pack_forget()                     # adresa je već podešena: sakrij dugme
        else: s.b_azur_u.pack(side="right")
        s.crtaj_pregled()

    def boje(s):
        """Paleta za izabranu temu (u tihom modu prigušena)."""
        if s.tema == "custom":
            base = mk_tema(s.cust_p, s.cust_a, s.cust_a)
        else:
            base = mk_tema(**TEME.get(s.tema, TEME["iron"]))
        if s.tihi:
            bg = base["bg"]
            return {k: (v if k == "bg" else mix(bg, v, 0.42)) for k, v in base.items()}
        return base

    def pokazi_tab(s, k):
        for f in s.tab_f.values(): f.pack_forget()
        s.tab = k; s.tab_f[k].pack(); s.refresh_buttons()

    def postavi_temu(s, ime):
        s.tema = ime; s.C = s.boje()
        s.ui_zvuk("on"); s.spremi(); s.apply_theme(); s.set_state(s.state if s.state == "think" else "idle")

    def izaberi_boju(s, koja):
        try:
            from tkinter import colorchooser
            start = s.cust_p if koja == "p" else s.cust_a
            hexc = colorchooser.askcolor(color=start, parent=s.root, title="Izaberi boju")[1]
        except Exception:
            return
        if not hexc or len(hexc) != 7: return
        if koja == "p": s.cust_p = hexc
        else: s.cust_a = hexc
        s.postavi_temu("custom")

    def crtaj_pregled(s):
        c, C = s.tema_prev, s.C
        c.configure(bg=C["bg"]); c.delete("all")
        for i, (hexc, naziv) in enumerate(((s.cust_p, "GLAVNA"), (s.cust_a, "AKCENT"))):
            x0 = i * 185
            c.create_rectangle(x0, 2, x0 + 175, 24, fill=hexc, outline=C["line"])
            c.create_text(x0 + 88, 13, text=naziv + "  " + hexc.upper(), fill=kontrast(hexc), font=("Consolas", 9, "bold"))

    def ui_zvuk(s, ime):
        """Kratki sci-fi zvuk pri kliku (isključen u tihom modu i kad su efekti off)."""
        if s.tihi or not s.efekat: return
        try:
            import winsound
            p = res("ui_%s.wav" % ime)
            if os.path.exists(p): winsound.PlaySound(p, winsound.SND_FILENAME | winsound.SND_ASYNC)
        except Exception:
            pass

    def toggle_panel(s):
        s.panel_on = not s.panel_on
        s.bg_key = None
        if s.panel_on:
            s.top.delete("reaktor"); s.top.delete("bat")
            s.top.itemconfigure("ui", state="hidden")
            s.top.configure(height=48)
            s.chat_c.pack_forget(); s.row.pack_forget()
            s.panel.pack(side="top", fill="both", expand=True, padx=6, pady=(0, 8))
            s.panel_c.lower()
        else:
            s.panel.pack_forget()
            s.top.configure(height=s.TOP_PUNO)
            s.top.itemconfigure("ui", state="normal")
            s.row.pack(side="bottom", fill="x", padx=14, pady=(4, 14))
            s.chat_c.pack(side="top", fill="both", expand=True, padx=6)
            s.bat_crtaj()
        s.refresh_buttons()

    def toggle_glas(s):
        if s.tihi: return
        s.glas = not s.glas
        if not s.glas: s.govor.stop()
        s.ui_zvuk("on" if s.glas else "off"); s.spremi(); s.refresh_buttons()

    def ciklus_glasa(s):
        if s.tihi: return
        niz = ["vesna", "goran", "windows"] if s.edge_ima else ["windows"]
        if not s.edge_ima:
            s.add("err", "Za bosanski glas (Vesna/Goran) treba paket edge-tts. Pokreni instaliraj_jarvis.bat "
                         "(ili: python -m pip install edge-tts) i ponovo otvori Jarvisa.")
        s.glas_tip = niz[(niz.index(s.glas_tip) + 1) % len(niz)] if s.glas_tip in niz else niz[0]
        s.govor.tip = s.glas_tip; s.govor.stop()
        s.ui_zvuk("on"); s.spremi(); s.refresh_buttons()
        if s.glas and not s.tihi: s.govor.say("Ovako zvučim.")

    def toggle_efekat(s):
        if s.tihi: return
        if s.efekat: s.ui_zvuk("off")
        s.efekat = not s.efekat
        if s.efekat: s.ui_zvuk("on")
        s.spremi(); s.refresh_buttons()

    def toggle_tihi(s):
        s.tihi = not s.tihi
        if s.tihi: s.govor.stop()
        s.C = s.boje()
        s.ui_zvuk("on")                                             # čuje se samo pri izlasku iz tihog moda
        s.spremi(); s.apply_theme(); s.set_state(s.state if s.state == "think" else "idle")

    def toggle_stalno(s):
        s.stalno = not s.stalno
        if s.stalno:
            threading.Thread(target=s.start_slusanje, daemon=True).start()
        else:
            s.stop_slusanje()
        s.ui_zvuk("on" if s.stalno else "off")
        s.spremi(); s.refresh_buttons(); s.set_state("idle")

    def toggle_uvod(s):
        s.uvod = not s.uvod
        s.ui_zvuk("on" if s.uvod else "off"); s.spremi(); s.refresh_buttons()

    # ---------- filmsko pokretanje ----------
    def pozdrav(s):
        h = time.localtime().tm_hour
        g = "Dobro jutro" if 5 <= h < 11 else "Dobar dan" if 11 <= h < 18 else "Dobro veče" if 18 <= h < 23 else "Dobra noć"
        ime = getattr(jarvis, "IME", "")
        return g + (", " + ime if ime else "") + "."

    def film_linije(s):
        def red(lab, val):
            val = val() if callable(val) else val
            return lab + " " + "." * max(2, 36 - len(lab) - len(val) - 2) + " " + val
        gl = {"vesna": "VESNA", "goran": "GORAN", "windows": "WINDOWS"}.get(s.glas_tip, "WINDOWS")
        return [
            (lambda: "J.A.R.V.I.S  MK II", "gold"),
            (lambda: red("INICIJALIZACIJA SISTEMA", "OK"), "cy"),
            (lambda: red("ARC REAKTOR", "ONLINE"), "cy"),
            (lambda: red("SLUŠANJE", "AKTIVNO" if s.slusa else ("ISKLJUČENO" if not s.stalno else "NIJE DOSTUPNO")), "cy"),
            (lambda: red("GLAS", "TIH" if s.tihi else gl), "cy"),
            (lambda: red("BATERIJA", "█" * s.bat_celije() + "░" * (10 - s.bat_celije())), "cy"),
            (lambda: red("VEZA S GEMINI", "OK" if s.chat else "NEMA KLJUČA"), "cy"),
            (lambda: "", "cy"),
            (lambda: s.pozdrav().upper(), "gold"),
        ]

    def film_start(s):
        if s.film_on or s.panel_on or s.busy: return
        s.film_on, s.film_t0 = True, time.time()
        try:
            s.film_lin, s.film_i, s.film_k, s.film_item = s.film_linije(), 0, 0, None
            c, C = s.chat_c, s.C
            c.delete("intro")
            s.film_y0 = c.canvasy(0)
            W = max(320, c.winfo_width())
            maxw = W - 100
            x0, y0 = 14, s.film_y0 + 12
            tx0 = x0 + 12
            ty0 = y0 + 10 + s.lh
            bottom = ty0 + len(s.film_lin) * 26 + 8
            s.film_box = (x0, y0, x0 + maxw, bottom)
            s.film_tx0, s.film_ty0 = tx0, ty0
            c.create_rectangle(x0, y0, x0 + maxw, bottom, fill=C["panel"], outline=C["line"], tags="intro")
            c.create_text(tx0, y0 + 8, text="JARVIS  ›", anchor="nw", fill=C["cy"], font=FONTB, tags="intro")
            s.reaktor_zvuk(); s.set_state("think", "POKRETANJE SISTEMA")
            s.film_korak()
        except Exception:
            prijavi_gresku(traceback.format_exc(), prikazi=False)
            s.film_kraj()

    def film_korak(s):
        if not s.film_on: return
        try:
            s._film_korak()
        except Exception:
            prijavi_gresku(traceback.format_exc(), prikazi=False)
            s.film_kraj()

    def _film_korak(s):
        c, C = s.chat_c, s.C
        if s.film_i >= len(s.film_lin):
            s.root.after(1000, s.film_kraj); return
        f, boja = s.film_lin[s.film_i]
        if s.film_k == 0:
            s.film_cur = f()
            s.film_item = c.create_text(s.film_tx0, s.film_ty0 + s.film_i * 26, anchor="nw", text="", fill=C[boja], font=("Consolas", 11, "bold"), tags="intro")
        s.film_k += 2
        c.itemconfigure(s.film_item, text=s.film_cur[:s.film_k])
        if s.film_k >= len(s.film_cur):
            s.film_i += 1; s.film_k = 0
            s.root.after(120, s.film_korak)
        else:
            s.root.after(18, s.film_korak)

    def film_kraj(s):
        if not s.film_on: return
        s.film_on = False
        try: s.chat_c.delete("intro")
        except Exception: pass
        s.set_state("idle"); s.film_pozdrav()

    def film_pozdrav(s):
        g = s.pozdrav()
        s.add("ai", g, False)
        if s.glas and not s.tihi:
            kasni = max(0.0, s.zvuk_do - time.time())            # sačekaj kraj zvuka reaktora
            s.root.after(int(kasni * 1000), lambda: s.govor.say(g + " Svi sistemi su spremni."))

    def film_pozadina(s):
        """Pokretanje skriveno (npr. s Windowsom): samo zvuk reaktora i glasovni pozdrav."""
        s.reaktor_zvuk(); s.film_pozdrav()

    def toggle_start(s):
        zeljeno = not s.start_on
        try:
            postavi_pokretanje(zeljeno)
        except Exception as e:
            s.add("err", "Ne mogu promijeniti pokretanje s Windowsom: " + str(e)[:80])
        s.start_on = pokretanje_ukljuceno()
        if s.start_on != zeljeno:
            s.add("err", "Pokretanje s Windowsom nije se promijenilo. Pritisni Win+R, upiši shell:startup i obriši Jarvis iz tog foldera.")
        else:
            s.ui_zvuk("on" if s.start_on else "off")
        s.refresh_buttons()

    def ocisti(s):
        s.msgs = []; s.hist = []; spremi_json(HIST, [])
        if s.klijent:
            try: s.chat = s.napravi_chat(s.mi, False)
            except Exception: pass
        s.layout(); s.toggle_panel()

    # ---------- baterija (procjena dnevne kvote besplatnog plana) ----------
    def bat_provjeri_dan(s):
        d = pac_datum()
        if d != s.dan:
            s.dan, s.iskoristeno, s.prazna = d, 0, False
            try: s.spremi()
            except Exception: pass

    def bat_celije(s):
        """Broj popunjenih kockica (0 do 10)."""
        if s.prazna: return 0
        f = 1 - s.iskoristeno / s.limit
        return 0 if f <= 0 else min(10, int(math.ceil(f * 10)))

    def bat_dodaj(s, n=1):
        s.bat_provjeri_dan(); s.iskoristeno += n
        s.spremi(); s.bat_crtaj()

    def bat_crtaj(s):
        W = s.top.winfo_width()
        if W < 100: return
        C = s.C; k = s.bat_celije()
        col = C["cy"] if k > 5 else (C["gold"] if k > 2 else C["red"])
        s.top.delete("bat")
        c = Pomak(s.top, W - 16 - 88 - 10 - 80, 15, "bat")
        c.create_rectangle(2, 4, 72, 22, outline=C["cy2"], width=2)
        c.create_rectangle(72, 10, 76, 16, fill=C["cy2"], outline="")
        for i in range(10):
            x = 5 + i * 6.6
            c.create_rectangle(x, 7, x + 5, 19, fill=(col if i < k else mix(C["bg"], C["cy2"], 0.35)), outline="")

    def cuo_set(s, t):
        s.cuo.configure(text=t[:70])

    def slusaj_instancu(s):
        if _SRV is None: return
        while True:
            try:
                conn, _ = _SRV.accept()
                d = conn.recv(16); conn.close()
                if b"show" in d: s.ui(lambda: s.pokazi(False))
            except Exception:
                time.sleep(0.5)

    # ---------- prozor / pozadina ----------
    def povuci_prozor(s):
        """Prozor nema naslovnu traku: povlači se mišem za gornji dio; dvoklik na kuglu ga sakrije, na naslov pušta uvod."""
        s.top.bind("<ButtonPress-1>", s._drag_start, add="+")
        s.top.bind("<B1-Motion>", s._drag_move, add="+")
        s.top.tag_bind("reaktor", "<Double-Button-1>", lambda e: s.sakrij())
        s.title.bind("<Double-Button-1>", lambda e: s.film_start(), add="+")

    def top_raspored(s):
        W = s.top.winfo_width()
        if W < 100: return
        s.title.moveto(16, 26)
        s.mk.moveto(16 + s.f_naslov.measure("J.A.R.V.I.S") + 8, 31)
        s.top.coords(s.opc_id, W - 16, 12)
        s.clock.moveto(W - 16, 58)
        s.top_cx = W / 2
        if not s.panel_on:
            s.bat_crtaj()

    def _drag_start(s, e):
        s._dx, s._dy = e.x_root - s.root.winfo_x(), e.y_root - s.root.winfo_y()

    def _drag_move(s, e):
        s.root.geometry("+%d+%d" % (e.x_root - s._dx, e.y_root - s._dy))

    def bez_okvira(s):
        """Uklanja naslovnu traku i okvir (zadržava ikonu u taskbaru)."""
        w0, h0 = 500, min(760, s.root.winfo_screenheight() - 110)
        try:
            import ctypes
            s.root.update_idletasks()
            u = ctypes.windll.user32
            hwnd = u.GetParent(s.root.winfo_id()) or s.root.winfo_id()
            st = u.GetWindowLongW(hwnd, -16)
            st &= ~(0x00C00000 | 0x00040000)                 # WS_CAPTION | WS_THICKFRAME
            u.SetWindowLongW(hwnd, -16, st)
            u.SetWindowPos(hwnd, 0, 0, 0, 0, 0, 0x0037)      # SWP_FRAMECHANGED
            s.root.update_idletasks()
            s.root.geometry("%dx%d" % (w0, h0))
        except Exception:
            try: s.root.overrideredirect(True)               # rezerva (nestaje ikona u taskbaru)
            except Exception: pass

    def sakrij_iz_menija(s):
        if s.panel_on: s.toggle_panel()
        s.sakrij()

    def korisnik(s):
        s.zadnja = time.time(); s.otvoren_glasom = False
        if s.film_on and time.time() - s.film_t0 > 0.8: s.film_kraj()

    def sakrij(s):
        s.root.withdraw(); s.hidden = True

    def pokazi(s, glasom=False):
        if s.hidden:
            s.root.deiconify(); s.hidden = False; s.otvoren_glasom = glasom
            s.root.after(80, s.layout)
        s.root.lift(); s.root.attributes("-topmost", True)
        s.root.after(700, lambda: s.root.attributes("-topmost", False))
        s.zadnja = time.time()

    # ---------- razgovor (crta se na platnu preko pozadine) ----------
    def ui(s, fn):
        s.ui_q.put(fn)

    def add(s, tag, txt, sacuvaj=True):
        s.msgs.append((tag, txt)); s.stick = True; s.layout()
        if sacuvaj and s.hist_on and tag in ("me", "ai"):
            s.hist.append(dict(u=tag, t=txt, v=time.strftime("%Y-%m-%d %H:%M")))
            s.hist = s.hist[-HIST_MAX:]; spremi_json(HIST, s.hist)

    def layout(s):
        c = s.chat_c; W, H = c.winfo_width(), c.winfo_height()
        if W < 120: return
        C = s.C
        c.delete("msg"); c.delete("bub")
        maxw = W - 100; y = 12
        for i, (tag, txt) in enumerate(s.msgs):
            me = tag == "me"
            x0 = W - 14 - maxw if me else 14
            lab = {"me": "TI  ›", "ai": "JARVIS  ›", "err": "SISTEM  ›"}[tag]
            labc = {"me": C["gold"], "ai": C["cy"], "err": C["red"]}[tag]
            c.create_text(x0 + 12, y + 8, text=lab, anchor="nw", fill=labc, font=FONTB, tags="msg")
            t2 = c.create_text(x0 + 12, y + 10 + s.lh, text=txt, anchor="nw", width=maxw - 24,
                               fill=C["red"] if tag == "err" else C["ink"], font=FONT, tags="msg")
            b = c.bbox(t2); bottom = (b[3] if b else y + 40) + 10
            c.create_rectangle(x0, y, x0 + maxw, bottom, fill=C["me"] if me else C["panel"],
                               outline=C["line"], tags="bub")
            if tag == "ai": s.kopiraj_ikona(c, i, x0 + maxw - 30, y + 9, C)
            y = bottom + 12
        c.tag_lower("bub")
        for t in ("bgp", "bgs", "bgf1", "bgf2"): c.tag_lower(t)
        c.configure(scrollregion=(0, 0, W, max(y, H)))
        if s.stick: c.yview_moveto(1.0)

    def kolo(s, e):
        if s.panel_on: return
        s.chat_c.yview_scroll(-1 if e.delta > 0 else 1, "units")
        s.stick = s.chat_c.yview()[1] >= 0.99

    # ---------- pozadina razgovora: odijelo lika + energija koja teče ----------
    def bg_gradi(s, W, H):
        rng = random.Random(W * 31 + H * 17 + sum(map(ord, s.tema)))
        C, tema = s.C, s.tema
        paths, p1, p2 = [], [], []
        d = dict(static=True, line=C["cy"], lo=0.10, hi=0.24, f1=C["cy"], f1lo=0.05, f1hi=0.12,
                 f2=C["gold"], f2lo=0.05, f2hi=0.12, pc=C["cy"], n=12, v=(2.0, 3.4), ln=(55, 90))
        if tema == "iron":                                   # oklopne ploče (šestouglovi), crveno-zlatno + više i brže energije
            R = 22; w = math.sqrt(3) * R
            for r in range(int(H / (1.5 * R)) + 3):
                for q in range(int(W / w) + 3):
                    cx = q * w - w + (w / 2 if r % 2 else 0); cy = r * 1.5 * R - R
                    pts = [(cx + R * math.cos(math.radians(60 * k - 30)), cy + R * math.sin(math.radians(60 * k - 30))) for k in range(7)]
                    paths.append(mk_path(pts))
                    if rng.random() < 0.10: p1.append(pts[:6])
            d.update(line=C["gold"], lo=0.12, hi=0.28, f1="#c4161c", f1lo=0.12, f1hi=0.26, pc=C["cy"], n=34, v=(3.2, 5.8), ln=(65, 120))
        elif tema == "spider":                               # mreža odijela, crveno-plavo
            cx, cy = W * 0.5, H * 0.45; Rmax = math.hypot(W, H) * 0.62; n = 16
            ang = [2 * math.pi * i / n + rng.uniform(-0.05, 0.05) for i in range(n)]
            for a in ang: paths.append(mk_path([(cx, cy), (cx + Rmax * math.cos(a), cy + Rmax * math.sin(a))]))
            rings = list(range(30, int(Rmax), 30))
            for ri, r in enumerate(rings):
                for i in range(n):
                    a1, a2 = ang[i], ang[(i + 1) % n]
                    if a2 < a1: a2 += 2 * math.pi
                    am = (a1 + a2) / 2
                    P1 = (cx + r * math.cos(a1), cy + r * math.sin(a1)); P2 = (cx + r * math.cos(a2), cy + r * math.sin(a2))
                    M = (cx + r * 0.92 * math.cos(am), cy + r * 0.92 * math.sin(am))
                    paths.append(mk_path([P1, M, P2]))
                    if ri > 0 and rng.random() < 0.10:
                        r0 = rings[ri - 1]
                        poly = [(cx + r0 * math.cos(a1), cy + r0 * math.sin(a1)), P1, P2, (cx + r0 * math.cos(a2), cy + r0 * math.sin(a2))]
                        (p1 if rng.random() < 0.5 else p2).append(poly)
            d.update(line=C["cy"], lo=0.12, hi=0.26, f1=C["cy"], f1lo=0.08, f1hi=0.18, f2=C["gold"], f2lo=0.10, f2hi=0.22,
                     pc=mix(C["cy"], "#ffffff", 0.4), n=18, v=(2.2, 4.0), ln=(50, 90))
        elif tema == "batman":                               # oklopni rebrasti šavovi + pravi Batman logo
            step, amp, dx = 26, 12, 22
            for k, y in enumerate(range(-amp, H + step, step)):
                pts = [(x, y + (amp if j % 2 else 0)) for j, x in enumerate(range(-dx, W + 2 * dx, dx))]
                paths.append(mk_path(pts if k % 2 == 0 else pts[::-1]))
            E = [
                (-1.00, -0.18), (-0.82, -0.25), (-0.60, -0.26), (-0.38, -0.23), (-0.22, -0.18),
                (-0.14, -0.23), (-0.10, -0.44), (-0.05, -0.28), (0.00, -0.27),
                (0.05, -0.28), (0.10, -0.44), (0.14, -0.23),
                (0.22, -0.18), (0.38, -0.23), (0.60, -0.26), (0.82, -0.25), (1.00, -0.18),
                (0.84, -0.05), (0.76, 0.12), (0.64, 0.04), (0.48, 0.07), (0.38, 0.24),
                (0.26, 0.13), (0.14, 0.16), (0.00, 0.40),
                (-0.14, 0.16), (-0.26, 0.13), (-0.38, 0.24), (-0.48, 0.07), (-0.64, 0.04),
                (-0.76, 0.12), (-0.84, -0.05)
            ]
            top_ref = 48 if s.panel_on else s.TOP_PUNO
            ex, ey, es = W * 0.5, (top_ref + H) * 0.5, min(W * 0.44, (H - top_ref) * 0.92)
            poly = [(ex + x * es, ey + y * es) for x, y in E]
            p1.append(poly)
            d["bat_poly"] = poly
            d.update(line=C["gold"], lo=0.10, hi=0.20, f1=C["cy"], f1lo=0.06, f1hi=0.15, pc=C["cy"], n=14, v=(2.5, 4.5), ln=(55, 105))
        elif tema == "matrix":                               # digitalna kiša
            for x in range(8, W, 14): paths.append(mk_path([(x, -10), (x, H + 10)]))
            d.update(line=C["cy"], lo=0.03, hi=0.07, pc=mix(C["cy"], "#ffffff", 0.5), n=max(8, int(len(paths) * 0.9)),
                     v=(3.0, 8.0), ln=(90, 170))
        else:                                                # custom: strujne staze
            g = 24
            for _ in range(20):
                x = rng.randrange(0, W // g + 1) * g; y = rng.randrange(0, H // g + 1) * g
                pts = [(x, y)]; horiz = rng.random() < 0.5
                for _k in range(rng.randint(3, 7)):
                    L = rng.randint(2, 6) * g * rng.choice((-1, 1))
                    if horiz: x += L
                    else: y += L
                    pts.append((x, y)); horiz = not horiz
                paths.append(mk_path(pts))
                for (px, py) in (pts[0], pts[-1]): p1.append([(px - 3, py - 3), (px + 3, py - 3), (px + 3, py + 3), (px - 3, py + 3)])
            d.update(line=C["cy"], lo=0.10, hi=0.24, f1=C["gold"], f1lo=0.18, f1hi=0.34, pc=C["gold"], n=14, v=(2.0, 3.6), ln=(60, 110))
        d["paths"], d["p1"], d["p2"] = paths, p1, p2
        d["pulses"] = [dict(p=(i % len(paths)) if tema == "matrix" else rng.randrange(len(paths)),
                            d=-rng.uniform(0, 260), v=rng.uniform(*d["v"]), ln=rng.uniform(*d["ln"])) for i in range(d["n"])]
        return d

    def _u_poligonu(s, x, y, poly):
        inside = False
        n = len(poly)
        j = n - 1
        for i in range(n):
            xi, yi = poly[i]; xj, yj = poly[j]
            if ((yi > y) != (yj > y)) and (x < (xj - xi) * (y - yi) / ((yj - yi) or 1e-9) + xi):
                inside = not inside
            j = i
        return inside

    def _blizu_poligona(s, x, y, poly, margina=6.0):
        if s._u_poligonu(x, y, poly):
            return True
        m2 = margina * margina
        for i in range(len(poly)):
            x1, y1 = poly[i]; x2, y2 = poly[(i + 1) % len(poly)]
            dx, dy = x2 - x1, y2 - y1
            l2 = dx * dx + dy * dy
            t = max(0.0, min(1.0, ((x - x1) * dx + (y - y1) * dy) / l2)) if l2 > 0 else 0.0
            px, py = x1 + t * dx, y1 + t * dy
            if (x - px) ** 2 + (y - py) ** 2 <= m2:
                return True
        return False

    def _podijeli_van_zone(s, pts, zabranjeno):
        """Dijeli liniju na segmente koji ne prelaze preko zabranjene zone."""
        rez, cur = [], []
        for p in pts:
            if zabranjeno(p[0], p[1]):
                if len(cur) >= 2: rez.append(cur)
                cur = []
            else:
                cur.append(p)
        if len(cur) >= 2: rez.append(cur)
        return rez

    def bg_celji(s):
        """Jedna koordinatna ravan za pozadinu: vrh i razgovor (ili opcije) dijele isti X/Y sistem."""
        th = int(s.top.winfo_height())
        if s.panel_on:
            ph = int(s.panel_c.winfo_height())
            return [dict(c=s.top, sh=0.0, g0=0, g1=th, t="t", k=1.0),
                    dict(c=s.panel_c, sh=-th, g0=th, g1=th + ph, t="p", k=1.0)]
        ch = int(s.chat_c.winfo_height())
        y0 = s.chat_c.canvasy(0)
        return [dict(c=s.top, sh=0.0, g0=0, g1=th, t="t", k=1.0),
                dict(c=s.chat_c, sh=y0 - th, g0=th, g1=th + ch, t="", k=1.0)]

    def bg_crtaj(s, W, key):
        celji = s.bg_celji()
        for t in celji:
            for tag in ("bgs", "bgf1", "bgf2", "bgp"): t["c"].delete(t["t"] + tag)
        s.bg = s.bg_gradi(W, celji[1]["g1"]); s.bg_key = key; bgc = s.C["bg"]
        for t in celji:
            c, sh = t["c"], t["sh"]
            for tag, lst in (("bgf1", s.bg["p1"]), ("bgf2", s.bg["p2"])):
                for poly in lst:
                    ys = [y for x, y in poly]
                    if max(ys) < t["g0"] - 6 or min(ys) > t["g1"] + 6: continue
                    c.create_polygon(*[v for x, y in poly for v in (x, y + sh)], fill=bgc, outline="", tags=t["t"] + tag)
            if s.bg["static"]:
                for P in s.bg["paths"]:
                    if P["y1"] < t["g0"] - 6 or P["y0"] > t["g1"] + 6: continue
                    c.create_line(*[v for x, y in P["pts"] for v in (x, y + sh)], fill=bgc, width=1, tags=t["t"] + "bgs")
        s.bg_sh = celji[1]["sh"]

    def bg_tick(s):
        glavno = s.panel_c if s.panel_on else s.chat_c
        W, hc, th = glavno.winfo_width(), glavno.winfo_height(), s.top.winfo_height()
        if W < 120 or hc < 60 or th < 30: return
        key = (W, hc, th, s.tema, s.cust_p, s.cust_a, s.tihi, s.panel_on)
        if key != s.bg_key: s.bg_crtaj(W, key)
        celji = s.bg_celji(); bgd, C = s.bg, s.C
        if not s.panel_on:
            d = celji[1]["sh"] - s.bg_sh                                # razgovor se skrolao
            if d:
                for tg in ("bgs", "bgf1", "bgf2"): s.chat_c.move(tg, 0, d)
                s.bg_sh = celji[1]["sh"]
        k0 = 0.5 if s.tihi else 1.0
        b = 0.5 + 0.5 * math.sin(s.phase * 0.7)                         # pulsiranje
        for t in celji:
            cc, pre, k = t["c"], t["t"], t["k"] * k0
            cc.itemconfigure(pre + "bgs", fill=mix(C["bg"], bgd["line"], k * (bgd["lo"] + (bgd["hi"] - bgd["lo"]) * b)))
            if bgd["p1"]: cc.itemconfigure(pre + "bgf1", fill=mix(C["bg"], bgd["f1"], k * (bgd["f1lo"] + (bgd["f1hi"] - bgd["f1lo"]) * b)))
            if bgd["p2"]: cc.itemconfigure(pre + "bgf2", fill=mix(C["bg"], bgd["f2"], k * (bgd["f2lo"] + (bgd["f2hi"] - bgd["f2lo"]) * (1 - b))))
            cc.delete(pre + "bgp")

        bat_poly = bgd.get("bat_poly") if s.tema == "batman" else None
        r_reaktor = s.SZ / 2 + 2
        film_box = getattr(s, "film_box", None) if (s.film_on and not s.panel_on) else None

        def zabranjeno(x, y):
            if not s.panel_on and math.hypot(x - s.top_cx, y - s.top_cy) <= r_reaktor:
                return True
            if bat_poly and s._blizu_poligona(x, y, bat_poly, 4.0):
                return True
            if film_box:
                cy = y + celji[1]["sh"]
                if film_box[0] <= x <= film_box[2] and film_box[1] <= cy <= film_box[3]:
                    return True
            return False

        vf = 0.5 if s.tihi else 1.0                                     # energija koja teče
        for pl in bgd["pulses"]:
            P = bgd["paths"][pl["p"]]
            pl["d"] += pl["v"] * vf
            if pl["d"] - pl["ln"] > P["L"]:
                pl["p"] = random.randrange(len(bgd["paths"])) if s.tema != "matrix" else pl["p"]
                pl["d"] = -random.uniform(0, 120 if s.tema != "matrix" else 260); continue
            d1 = pl["d"]; d0 = d1 - pl["ln"]; n = max(6, int(pl["ln"] / 4))
            raw_pts = [tacka_na(P, d0 + (d1 - d0) * i / n) for i in range(n + 1) if d0 + (d1 - d0) * i / n >= 0]
            if len(raw_pts) < 2: continue
            glava_vidljiva = not zabranjeno(*raw_pts[-1])
            seg_lista = s._podijeli_van_zone(raw_pts, zabranjeno)
            for si, pts in enumerate(seg_lista):
                ymin, ymax = min(y for x, y in pts), max(y for x, y in pts)
                crta_glavu = glava_vidljiva and (si == len(seg_lista) - 1)
                for t in celji:
                    if ymax < t["g0"] - 6 or ymin > t["g1"] + 6: continue
                    cc, k, sh = t["c"], t["k"] * k0, t["sh"]
                    if s.tema == "matrix":
                        cc.create_line(*[v for x, y in pts for v in (x, y + sh)], width=2,
                                       fill=mix(C["bg"], bgd["pc"], k * 0.72), tags=t["t"] + "bgp")
                    else:
                        dijelova = 3; po = max(1, len(pts) // dijelova)
                        for i in range(dijelova):
                            seg = pts[i * po:(i + 1) * po + 1] if i < dijelova - 1 else pts[i * po:]
                            if len(seg) >= 2:
                                cc.create_line(*[v for x, y in seg for v in (x, y + sh)], width=1 if i == 0 else 2,
                                               fill=mix(C["bg"], bgd["pc"], k * (0.25 + 0.7 * (i + 1) / dijelova)), tags=t["t"] + "bgp")
                    if crta_glavu:
                        hx, hy = pts[-1]
                        cc.create_oval(hx - 2, hy + sh - 2, hx + 2, hy + sh + 2, fill=mix(C["bg"], bgd["pc"], k * 0.95), outline="", tags=t["t"] + "bgp")
        # Osiguraj da su pozadina i energije uvijek ISPOD reaktora, UI natpisa i teksta inicijalizacije
        for t in celji:
            cc = t["c"]
            for tag in ("bgp", "bgs", "bgf1", "bgf2"):
                cc.tag_lower(t["t"] + tag)
            for fg_tag in ("reaktor", "bat", "ui", "intro", "bub", "msg"):
                if cc.find_withtag(fg_tag):
                    cc.tag_raise(fg_tag)

    # ---------- stanje i reaktor ----------
    def set_state(s, st, tekst=None):
        s.state = st
        names = {"idle": "SPREMAN", "listen": "SLUŠAM", "think": "OBRAĐUJEM", "speak": "GOVORIM"}
        t = tekst or names[st]
        if s.prazna and st == "idle": t = "BATERIJA PRAZNA"
        elif st == "idle" and s.slusa: t = "SPREMAN  ·  SLUŠAM „JARVIS“"
        if s.tihi: t += "  ·  TIHI MOD"
        s.status.configure(text="■ " + t, fg=(s.C["red"] if s.prazna else (s.C["mute"] if s.tihi else s.C["gold"])))

    def reaktor(s):
        C, p = s.C, s.phase
        s.top.delete("reaktor")
        c = Pomak(s.top, s.top_cx - s.SZ / 2, s.top_cy - s.SZ / 2, "reaktor")
        S = s.SZ; cx = cy = S / 2; R = S / 2 - 4
        sp = {"idle": 0.6, "listen": 1.4, "think": 3.2, "speak": 1.6}[s.state] * (0.35 if s.tihi else 1)
        main = C["gold"] if s.state == "listen" else C["cy"]
        amp = {"idle": 0.12, "listen": 0.45, "think": 0.25, "speak": 0.8}[s.state]
        if s.prazna:
            main, sp, amp = C["red"], 0.2, 0.05
        if s.gasi:                                                  # gašenje reaktora
            f = max(0.0, 1 - (time.time() - s.gasi_t0) / 1.5)
            main = mix(C["bg"], main, f); sp *= f; amp = 0.3 * f
        puls = 1 + amp * math.sin(p * (3 if s.state in ("speak", "listen") else 1.2))
        for i in range(7, 0, -1):                                   # sjaj
            r = R * 0.30 * (1 + i * 0.17) * (0.97 + 0.03 * puls)
            c.create_oval(cx - r, cy - r, cx + r, cy + r, fill=mix(C["bg"], main, (8 - i) * (0.012 if s.prazna else 0.045)), outline="")
        for k in range(72):                                         # skala sa crticama
            a = math.radians(k * 5 + p * sp * 6); lng = k % 6 == 0
            r1 = R * (0.92 if lng else 0.95)
            c.create_line(cx + r1 * math.cos(a), cy - r1 * math.sin(a), cx + R * math.cos(a), cy - R * math.sin(a),
                          fill=main if lng else C["cy2"], width=2 if lng else 1)
        r = R * 0.84
        for k in range(3):                                          # vanjski segmenti
            c.create_arc(cx - r, cy - r, cx + r, cy + r, start=(k * 120 - p * sp * 14) % 360, extent=78,
                         style="arc", outline=main, width=3)
        r = R * 0.72
        for k in range(12):                                         # zlatni prsten
            c.create_arc(cx - r, cy - r, cx + r, cy + r, start=(k * 30 + p * sp * 20) % 360, extent=12,
                         style="arc", outline=C["gold"], width=2)
        r = R * 0.56
        c.create_oval(cx - r, cy - r, cx + r, cy + r, outline=main, width=2)
        r = R * 0.42
        for k in range(10):                                         # zavojnice reaktora
            c.create_arc(cx - r, cy - r, cx + r, cy + r, start=k * 36 + 6, extent=24, style="arc",
                         outline=mix(C["bg"], main, 0.55), width=max(6, int(R * 0.15)))
        r = R * 0.27
        c.create_oval(cx - r, cy - r, cx + r, cy + r, outline=main, width=2)
        r = R * 0.2 * puls
        c.create_oval(cx - r, cy - r, cx + r, cy + r, fill=mix(main, "#ffffff", 0.6 if not s.tihi else 0.2), outline="")

    def tick(s):
        try:
            try:
                while True: s.ui_q.get_nowait()()
            except queue.Empty:
                pass
            if s.hidden:                                            # u pozadini ne crtamo (štedi procesor)
                s.root.after(100, s.tick); return
            s.phase += 0.1
            if s.state == "listen" and not s.busy and time.time() > s.expect_do:
                s.set_state("idle")                                 # nitko nije ništa rekao
            if not s.panel_on:
                s.reaktor()
            s.bg_tick()                                             # energije teku i kad su opcije otvorene
            s.clock.configure(text=time.strftime("%H:%M:%S"))
            if time.time() - s.zadnji_dan > 60:
                s.zadnji_dan = time.time(); s.bat_provjeri_dan(); s.bat_crtaj()
            if (s.otvoren_glasom and not s.busy and not s.govor.busy and s.state == "idle"
                    and time.time() - s.zadnja > 45):               # sam se sakrije nakon razgovora
                s.sakrij()
        except Exception:
            prijavi_gresku(traceback.format_exc(), prikazi=False)
        s.root.after(40, s.tick)

    # ---------- pitanje prije otvaranja ----------
    def potvrdi(s, opis):
        """Poziva se iz niti alata: pita korisnika (DA/NE ili glasom) i čeka odgovor."""
        ev, res = threading.Event(), {"v": False}
        s.pita = (ev, res)
        s.ui(lambda: s.prikazi_pitanje(opis))
        ok = ev.wait(s.potvrda_cekanje)                       # bez odgovora = ne
        s.pita = None
        s.ui(s.sakrij_pitanje)
        return bool(ok and res["v"])

    def prikazi_pitanje(s, opis):
        s.pokazi(True)
        s.pitanje_l.configure(text="Mogu li " + opis + "?  (klikni DA/NE ili reci da/ne)")
        s.pitanje_f.pack(side="bottom", fill="x", padx=14, pady=(0, 4), before=s.chat_c)
        if s.glas and not s.tihi: s.govor.say("Mogu li " + opis + "?")

    def sakrij_pitanje(s):
        try: s.pitanje_f.pack_forget()
        except Exception: pass

    def odgovori(s, v):
        if s.pita:
            ev, res = s.pita
            res["v"] = v; ev.set()
            s.govor.stop()

    def dodaj_alate(s):
        """Dodaje alate za rad s dokumentima i tekstom (pišu u mapu Dokumenti\\Jarvis dokumenti)."""
        if getattr(jarvis, "_dodani", False): return
        skriven = dict(stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=20)

        def napisi_dokument(tekst: str, naziv: str = "Jarvis dokument", vrsta: str = "word") -> str:
            """Pravi dokument sa zadanim tekstom i otvara ga. Parametar tekst je CIJELI sadržaj dokumenta.
            vrsta: 'word' (Word), 'tekst' (Notepad) ili 'excel' (tabela: redovi su odvojeni novim redom, kolone tačka-zarezom).
            U Word tekstu '# ' počinje naslov, '## ' podnaslov, a '- ' tačka u listi."""
            vrsta = str(vrsta or "word").lower()
            tekst = str(tekst).replace("\r\n", "\n")
            os.makedirs(DOK_DIR, exist_ok=True)
            ime = sigurno_ime(naziv) + " " + time.strftime("%Y-%m-%d %H-%M")
            if vrsta in ("word", "docx"):
                pth = os.path.join(DOK_DIR, ime + ".docx"); napravi_docx(pth, tekst)
            elif vrsta in ("excel", "csv", "tabela"):
                pth = os.path.join(DOK_DIR, ime + ".csv")
                with open(pth, "w", encoding="utf-8-sig", newline="") as f: f.write("sep=;\r\n" + tekst.replace("\n", "\r\n"))
            else:
                pth = os.path.join(DOK_DIR, ime + ".txt")
                with open(pth, "w", encoding="utf-8-sig", newline="") as f: f.write(tekst.replace("\n", "\r\n"))
            try:
                os.startfile(pth)
            except Exception as e:
                return "Dokument je sačuvan (" + pth + "), ali ga nisam mogao otvoriti: " + str(e)[:80]
            return "Dokument je napravljen i otvoren: " + pth

        def kopiraj_u_clipboard(tekst: str) -> str:
            """Kopira zadani tekst u clipboard (korisnik ga može zalijepiti sa Ctrl+V gdje god želi)."""
            try:
                subprocess.run(["powershell", "-NoProfile", "-Command", "Set-Clipboard -Value $env:JT"],
                               env=dict(os.environ, JT=str(tekst)), **skriven)
            except Exception as e:
                return "Nisam uspio kopirati tekst: " + str(e)[:80]
            return "Tekst je kopiran u clipboard."

        def zalijepi_tekst_u_aktivni_prozor(tekst: str) -> str:
            """Kopira tekst i zalijepi ga (Ctrl+V) u prozor koji je korisnik prethodno imao aktivan (npr. otvoren Word, mail ili forma)."""
            r = kopiraj_u_clipboard(tekst)
            if not r.startswith("Tekst je kopiran"): return r
            s.ui(lambda: s.root.withdraw())                      # fokus se vraća prethodnom prozoru
            time.sleep(1.0)
            try:
                subprocess.run(["powershell", "-NoProfile", "-Command",
                                "Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.SendKeys]::SendWait('^v')"], **skriven)
                rez = "Tekst je zalijepljen u aktivni prozor."
            except Exception as e:
                rez = "Tekst je kopiran, ali ga nisam mogao zalijepiti (Ctrl+V ručno): " + str(e)[:60]
            time.sleep(0.4)
            s.ui(lambda: (s.root.deiconify(), s.pokazi(False)))
            return rez

        def zapamti(cinjenica: str) -> str:
            """Trajno zapamti informaciju o korisniku (ime, navike, preference, važni datumi...) kad korisnik kaže 'zapamti ...'."""
            c = str(cinjenica).strip()
            if not c: return "Nema šta da zapamtim."
            lista = ucitaj_json(PAMCENJE, [])
            if any(isinstance(m, dict) and m.get("t", "").lower() == c.lower() for m in lista): return "To već pamtim."
            lista.append(dict(t=c, v=time.strftime("%Y-%m-%d"))); spremi_json(PAMCENJE, lista)
            return "Zapamćeno."

        def zaboravi(kljucna_rijec: str) -> str:
            """Briše zapamćene informacije koje sadrže zadanu riječ ili frazu."""
            k = str(kljucna_rijec).strip().lower()
            lista = ucitaj_json(PAMCENJE, [])
            ostalo = [m for m in lista if not (isinstance(m, dict) and k and k in m.get("t", "").lower())]
            spremi_json(PAMCENJE, ostalo)
            return "Obrisano zapisa: %d." % (len(lista) - len(ostalo))

        def sta_pamtis() -> str:
            """Vraća sve što je zapamćeno o korisniku."""
            lista = ucitaj_json(PAMCENJE, [])
            return "; ".join(m.get("t", "") for m in lista if isinstance(m, dict)) or "Još ništa ne pamtim."

        jarvis.ALATI = list(getattr(jarvis, "ALATI", [])) + [napisi_dokument, kopiraj_u_clipboard, zalijepi_tekst_u_aktivni_prozor,
                                                              zapamti, zaboravi, sta_pamtis]
        jarvis.SYSTEM = getattr(jarvis, "SYSTEM", "") + (
            " Ako korisnik traži da napišeš tekst (pismo, molbu, referat, listu, mail...) i otvoriš ga u Wordu, Notepadu ili Excelu, "
            "napiši cijeli tekst i pozovi alat napisi_dokument. Ako traži da nešto zalijepiš u drugi program, koristi "
            "zalijepi_tekst_u_aktivni_prozor ili kopiraj_u_clipboard. Poslije toga odgovori kratko, bez ponavljanja cijelog teksta. "
            "Kad korisnik kaže 'zapamti ...' pozovi alat zapamti, za 'zaboravi ...' alat zaboravi, a za pitanje šta pamtiš alat sta_pamtis.")
        jarvis._dodani = True

    def zastiti_alate(s):
        """Alati koji otvaraju aplikacije ili preglednik prvo pitaju korisnika."""
        if getattr(jarvis, "_zasticeno", False): return
        opisi = {
            "otvori_aplikaciju": lambda *a, **k: "otvoriti aplikaciju " + str(a[0] if a else k.get("naziv", "")),
            "trazi": lambda *a, **k: "otvoriti pretragu u pregledniku: " + str(a[0] if a else k.get("upit", "")),
            "napisi_dokument": lambda *a, **k: "napraviti " + {"word": "Word dokument", "docx": "Word dokument", "tekst": "tekstualni dokument",
                    "excel": "Excel tabelu", "csv": "Excel tabelu", "tabela": "Excel tabelu"}.get(
                    str(k.get("vrsta", a[2] if len(a) > 2 else "word")).lower(), "dokument") + " „" +
                    str(k.get("naziv", a[1] if len(a) > 1 else "Jarvis dokument")) + "“ i otvoriti ga",
            "zalijepi_tekst_u_aktivni_prozor": lambda *a, **k: "zalijepiti tekst u prozor koji je sada aktivan",
        }
        novi = []
        for f in getattr(jarvis, "ALATI", []):
            op = opisi.get(getattr(f, "__name__", ""))
            if op:
                def obal(f=f, op=op):
                    @functools.wraps(f)
                    def w(*a, **k):
                        if not s.potvrdi(op(*a, **k)):
                            return "Korisnik nije dozvolio."
                        return f(*a, **k)
                    return w
                f = obal()
            novi.append(f)
        jarvis.ALATI = novi; jarvis._zasticeno = True

    # ---------- historija i pamćenje ----------
    def memorija_tekst(s):
        lista = ucitaj_json(PAMCENJE, [])
        if not lista: return ""
        redovi = "\n".join("- " + str(m.get("t", "")) for m in lista[-100:] if isinstance(m, dict))
        return "\n\nO korisniku pamtiš sljedeće (koristi to prirodno kad je relevantno, ne ponavljaj bez potrebe):\n" + redovi[:3000]

    def gemini_historija(s, types):
        """Zadnjih nekoliko poruka kao kontekst za model (naizmjenično korisnik/model)."""
        out = []
        for m in s.hist[-24:]:
            rola = "user" if m["u"] == "me" else "model"
            if out and out[-1].role == rola: continue
            out.append(types.Content(role=rola, parts=[types.Part(text=str(m["t"])[:2000])]))
        while out and out[0].role != "user": out.pop(0)
        while out and out[-1].role != "model": out.pop()
        return out

    def napravi_chat(s, i, s_istorijom=True):
        try:
            from google.genai import types
            hist = s.gemini_historija(types) if (s_istorijom and s.hist_on) else []
            return s.klijent.chats.create(model=jarvis.MODELI[i], history=hist,
                                          config=types.GenerateContentConfig(system_instruction=jarvis.SYSTEM + s.memorija_tekst(),
                                                                              tools=jarvis.ALATI))
        except Exception:
            prijavi_gresku(traceback.format_exc(), prikazi=False)
            return jarvis.novi_razgovor(s.klijent, i)

    def prikazi_pamcenje(s):
        lista = ucitaj_json(PAMCENJE, [])
        tekst = "ONO ŠTO JARVIS PAMTI O TEBI\r\n\r\n" + ("\r\n".join("- %s   (%s)" % (m.get("t", ""), m.get("v", "")) for m in lista if isinstance(m, dict)) or "(još ništa)")
        pth = os.path.join(DATA, "jarvis_pamcenje.txt")
        try:
            with open(pth, "w", encoding="utf-8-sig", newline="") as f: f.write(tekst)
            os.startfile(pth)
        except Exception as e:
            s.add("err", "Ne mogu otvoriti pamćenje: " + str(e)[:80])

    def obrisi_pamcenje(s):
        spremi_json(PAMCENJE, [])
        if s.klijent:
            try: s.chat = s.napravi_chat(s.mi)
            except Exception: pass
        s.ui_zvuk("off"); s.add("ai", "Pamćenje je obrisano.", False)

    def promijeni_kljuc(s):
        try:
            from tkinter import simpledialog
            k = simpledialog.askstring("API ključ", "Zalijepi svoj besplatni Gemini API ključ\n(aistudio.google.com/apikey):",
                                       parent=s.root, show="*")
        except Exception:
            return
        if not k or not k.strip(): return
        try:
            with open(KLJUC, "w", encoding="utf-8") as f: f.write(k.strip())
        except Exception as e:
            s.add("err", "Ne mogu spremiti ključ: " + str(e)[:80]); return
        s.start_ai()
        s.ui_zvuk("on"); s.add("ai", "Ključ je spremljen." if s.chat else "Ključ je spremljen, ali veza još ne radi.", False)

    # ---------- automatsko ažuriranje ----------
    def toggle_azur(s):
        s.auto_azur = not s.auto_azur
        s.ui_zvuk("on" if s.auto_azur else "off"); s.spremi(); s.refresh_buttons()

    def postavi_adresu(s):
        try:
            from tkinter import simpledialog
            u = simpledialog.askstring("Ažuriranje", "Zalijepi adresu do version.json\n(npr. https://raw.githubusercontent.com/IME/jarvis-update/main/version.json):",
                                       initialvalue=azur_url(), parent=s.root)
        except Exception:
            return
        if u is None: return
        try:
            with open(AZUR_FAJL, "w", encoding="utf-8") as f: f.write(u.strip())
        except Exception as e:
            s.add("err", "Ne mogu spremiti adresu: " + str(e)[:80]); return
        s.ui_zvuk("on"); s.add("ai", "Adresa za ažuriranje je spremljena.", False)
        if u.strip(): s.provjeri_azuriranje(True)

    def azur_ciklus(s):
        if s.auto_azur and azur_url(): s.provjeri_azuriranje(False)
        s.root.after(6 * 3600 * 1000, s.azur_ciklus)

    def provjeri_azuriranje(s, rucno=False):
        threading.Thread(target=s._azur_rad, args=(rucno,), daemon=True).start()

    def azur_cilj(s):
        return os.path.join(DATA, "kod") if FROZEN else HERE

    def primijeni_paket(s, zip_path):
        """Raspakuje samo ravne datoteke dozvoljenih tipova; stare verzije sprema u _prije_azuriranja."""
        import zipfile, shutil
        cilj = s.azur_cilj(); os.makedirs(cilj, exist_ok=True)
        rezerva = os.path.join(cilj, "_prije_azuriranja"); os.makedirs(rezerva, exist_ok=True)
        n = 0
        with zipfile.ZipFile(zip_path) as z:
            for ime in z.namelist():
                if "/" in ime or "\\" in ime or ime.startswith(".") or not ime.lower().endswith(ALLOWED_EXT): continue
                put = os.path.join(cilj, ime)
                if os.path.exists(put): shutil.copy2(put, os.path.join(rezerva, ime))
                with z.open(ime) as src, open(put + ".novi", "wb") as dst: shutil.copyfileobj(src, dst)
                os.replace(put + ".novi", put); n += 1
        return n

    def _azur_rad(s, rucno):
        import urllib.request, hashlib, tempfile, shutil
        def poruka(t): s.ui(lambda: s.add("ai", t, False))
        url = azur_url()
        if not url:
            if rucno: poruka("Ažuriranje nije podešeno. Upiši adresu u OPCIJE > VIŠE > ADRESA AŽURIRANJA.")
            return
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "Jarvis"}), timeout=12) as r:
                man = json.loads(r.read().decode("utf-8"))
            nova = int(man.get("build", 0))
            if nova <= BUILD or s.azur_spreman >= nova:
                if rucno: poruka("Imaš najnoviju verziju (%s)." % VERZIJA)
                return
            paket = man.get("paket") or url.rsplit("/", 1)[0] + "/jarvis_update.zip"
            tmp = os.path.join(tempfile.gettempdir(), "jarvis_update_%d.zip" % nova)
            with urllib.request.urlopen(urllib.request.Request(paket, headers={"User-Agent": "Jarvis"}), timeout=90) as r, open(tmp, "wb") as f:
                shutil.copyfileobj(r, f)
            sha = str(man.get("sha256", "")).lower()
            if sha:
                with open(tmp, "rb") as f: h = hashlib.sha256(f.read()).hexdigest()
                if h != sha: raise RuntimeError("Paket nije prošao provjeru (sha256).")
            s.primijeni_paket(tmp); s.azur_spreman = nova
            poruka("Jarvis je ažuriran na verziju %s. %s" % (man.get("verzija", nova), man.get("napomena", "")))
            if s.potvrdi("ponovo pokrenuti Jarvisa da se ažuriranje primijeni"):
                s.ui(s.ponovo_pokreni)
        except Exception as e:
            prijavi_gresku("Ažuriranje: " + traceback.format_exc(), prikazi=False)
            if rucno: poruka("Ažuriranje nije uspjelo: " + str(e)[:80])

    def ponovo_pokreni(s):
        if FROZEN:
            naredba = '"%s"' % sys.executable
        else:
            pw = sys.executable
            if os.path.basename(pw).lower() == "python.exe": pw = os.path.join(os.path.dirname(pw), "pythonw.exe")
            naredba = '"%s" "%s"' % (pw, os.path.join(HERE, "jarvis_app.py"))
        if s.hidden: naredba += " --pozadina"
        try:
            subprocess.Popen('cmd /c ping 127.0.0.1 -n 3 >nul & start "" ' + naredba)
        except Exception:
            return
        s.stop_slusanje(); s.govor.stop(); s.kraj()

    # ---------- kopiranje poruka ----------
    def kopiraj_ikona(s, c, i, x, y, C):
        t = "cp%d" % i
        c.create_rectangle(x - 5, y - 5, x + 19, y + 20, outline="", fill=C["panel"], tags=("msg", t))
        c.create_rectangle(x + 4, y, x + 14, y + 11, outline=C["mute"], tags=("msg", t))
        c.create_rectangle(x, y + 4, x + 10, y + 15, outline=C["mute"], fill=C["panel"], tags=("msg", t))
        c.create_line(x + 2, y + 8, x + 8, y + 8, fill=C["mute"], tags=("msg", t))
        c.create_line(x + 2, y + 11, x + 8, y + 11, fill=C["mute"], tags=("msg", t))
        c.tag_bind(t, "<Button-1>", lambda e, i=i: s.kopiraj_poruku(i))
        c.tag_bind(t, "<Enter>", lambda e: c.configure(cursor="hand2"))
        c.tag_bind(t, "<Leave>", lambda e: c.configure(cursor=""))

    def kopiraj_poruku(s, i):
        try: tekst = s.msgs[i][1]
        except Exception: return
        try:
            s.root.clipboard_clear(); s.root.clipboard_append(tekst); s.root.update_idletasks()
        except Exception:
            pass
        def ps():                                           # i preko Windowsa, da ostane u clipboardu
            try:
                subprocess.run(["powershell", "-NoProfile", "-Command", "Set-Clipboard -Value $env:JT"], env=dict(os.environ, JT=tekst),
                               stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=15)
            except Exception:
                pass
        threading.Thread(target=ps, daemon=True).start()
        s.ui_zvuk("klik")
        c = s.chat_c; c.delete("kopirano")
        bb = c.bbox("cp%d" % i)
        if bb: c.create_text(bb[0] - 6, bb[1] + 7, text="KOPIRANO", anchor="ne", fill=s.C["gold"], font=("Consolas", 9, "bold"), tags=("msg", "kopirano"))
        s.root.after(1300, lambda: c.delete("kopirano"))

    def toggle_hist(s):
        s.hist_on = not s.hist_on
        s.ui_zvuk("on" if s.hist_on else "off"); s.spremi(); s.refresh_buttons()

    # ---------- AI ----------
    def start_ai(s):
        try:
            from google import genai
            kljuc = citaj_kljuc()
            s.klijent = genai.Client(api_key=kljuc) if kljuc else genai.Client()
            s.dodaj_alate()
            s.zastiti_alate()
            s.chat = s.napravi_chat(s.mi)
        except Exception as e:
            s.add("err", "Nema veze s Googleom ili nema API ključa. Upiši ga u OPCIJE > SISTEM > API KLJUČ. "
                         "i ponovo otvori program. (" + str(e)[:120] + ")")

    def salji(s):
        t = s.entry.tekst().strip(); s.entry.isprazni()
        if t and trazi_ekran(t): s.pitaj_o_ekranu(t)
        elif t: s.posalji(t)

    def klik_ekran(s):
        t = s.entry.tekst().strip(); s.entry.isprazni()
        s.pitaj_o_ekranu(t)

    def pitaj_o_ekranu(s, t, glasom=False):
        """Sakrije Jarvisa, uslika ekran, pa pošalje sliku zajedno s pitanjem."""
        if s.busy: return
        if not t: t = "Pogledaj moj ekran i kratko objasni šta vidiš."
        bio_skriven = s.hidden
        if not bio_skriven: s.root.withdraw()
        s.root.after(350, lambda: s._snimi_i_posalji(t, bio_skriven, glasom))

    def _snimi_i_posalji(s, t, bio_skriven, glasom):
        slika = snimi_ekran()
        if not bio_skriven:
            s.root.deiconify(); s.pokazi(False)
        elif glasom:
            s.pokazi(True)
        if slika is None:
            s.pokazi(); s.add("err", "Ne mogu uslikati ekran. Treba paket pillow: python -m pip install pillow"); return
        s.posalji(t, slika)

    def posalji(s, t, slika=None):
        if s.busy: return
        if t.lower().strip(" .!") in IZLAZ:
            s.zatvori(); return
        if not s.chat:
            s.pokazi(); s.add("err", "Jarvis nije povezan (nedostaje ključ)."); return
        s.govor.stop(); s.busy = True; s.zadnja = time.time()
        s.add("me", t); s.set_state("think")
        threading.Thread(target=s._pitaj, args=(t, slika), daemon=True).start()

    def _pitaj(s, t, slika=None):
        odg, greska, prazna, n = None, None, False, 1
        try:
            if slika:
                from google.genai import types
                poruka = [types.Part.from_bytes(data=slika, mime_type="image/jpeg"), t]
            else:
                poruka = t
            o = s.chat.send_message(poruka)
            odg = (o.text or "Gotovo.").replace("*", "")
            n = 2 + (2 if getattr(o, "automatic_function_calling_history", None) else 0) + (6 if slika else 0) + (1 if len(odg) > 500 else 0)
        except Exception as e:
            g = str(e)
            if ("404" in g or "NOT_FOUND" in g) and s.mi + 1 < len(jarvis.MODELI):
                s.mi += 1; s.chat = s.napravi_chat(s.mi)
                greska = "Prebacio sam se na drugi model. Ponovite pitanje."
            elif "429" in g or "RESOURCE_EXHAUSTED" in g:
                prazna = True
            elif "API key" in g or "401" in g or "403" in g:
                greska = "Problem s ključem. Pokrenite instaliraj_jarvis.bat i unesite ključ ponovo."
            else:
                greska = "Greška: " + g[:160]
        def gotovo():
            s.busy = False
            if odg:
                s.prazna = False; s.bat_dodaj(n); s.stigao_odgovor(odg)
            elif prazna:
                s.prazna = True; s.spremi(); s.bat_crtaj(); s.stigao_odgovor(PRAZNA)
            else:
                s.pokazi(); s.add("err", greska); s.set_state("idle")
        s.ui(gotovo)

    def stigao_odgovor(s, t):
        if s.hidden: s.pokazi(True)
        s.zadnja = time.time()
        s.add("ai", t)
        if s.glas and not s.tihi:
            kasni = max(0, s.zvuk_do - time.time())                 # sačekaj kraj zvuka reaktora
            s.root.after(int(kasni * 1000), lambda: s.govor.say(t))
        else:
            s.set_state("idle")

    # ---------- zvuk reaktora ----------
    def reaktor_zvuk(s):
        if s.tihi or not s.efekat or not os.path.exists(WAV): return
        try:
            import winsound
            winsound.PlaySound(WAV, winsound.SND_FILENAME | winsound.SND_ASYNC)
            s.zvuk_do = time.time() + 2.7
        except Exception:
            pass

    # ---------- slušanje ----------
    def start_slusanje(s):
        if s.slusa: return
        try:
            with open(FLAG, "w") as f: f.write(str(time.time()))
        except Exception:
            pass
        try:
            import speech_recognition as sr
            s.rec = sr.Recognizer(); s.rec.dynamic_energy_threshold = True; s.rec.pause_threshold = 0.8
            mic = sr.Microphone()
            with mic as izvor:
                s.rec.adjust_for_ambient_noise(izvor, 1.0)
            if not s.stalno:
                try: os.remove(FLAG)
                except Exception: pass
                return
            s.stop_bg = s.rec.listen_in_background(mic, s.on_audio, phrase_time_limit=12)
            s.slusa = True
            s.ui(lambda: (s.set_state("idle"), s.cuo_set("SLUŠAM: reci „Jarvis“")))
            time.sleep(10)                                         # preživjelo 10 s: slušanje je stabilno
            try: os.remove(FLAG)
            except Exception: pass
        except BaseException as e:
            try: os.remove(FLAG)
            except Exception: pass
            s.ui(lambda: s.add("err", "Slušanje nije dostupno (treba mikrofon i paket pyaudio: "
                                      "python -m pip install SpeechRecognition pyaudio). " + str(e)[:80]))

    def stop_slusanje(s):
        try:
            if s.stop_bg: s.stop_bg(wait_for_stop=False)
        except Exception:
            pass
        s.stop_bg, s.slusa, s.expect = None, False, False

    def on_audio(s, rec, audio):
        if (s.busy and s.pita is None) or s.govor.busy or time.time() < s.zvuk_do or not s.stalno:
            return
        import speech_recognition as sr
        try:
            t = rec.recognize_google(audio, language="hr-HR").lower().strip()
        except sr.UnknownValueError:
            s.ui(lambda: s.cuo_set("ČUO SAM: (nerazumljivo)")); return
        except sr.RequestError:
            s.ui(lambda: s.cuo_set("GREŠKA: nema veze s Googleovim prepoznavanjem govora")); return
        except Exception:
            return
        if not t: return
        s.ui(lambda h=t: s.cuo_set("ČUO SAM: " + h))
        if s.pita is not None:                                  # čeka se odgovor na pitanje
            rijeci = set(re.findall(r"\w+", t.lower()))
            if rijeci & NE_RIJECI: s.ui(lambda: s.odgovori(False))
            elif rijeci & DA_RIJECI: s.ui(lambda: s.odgovori(True))
            return
        wake, t = nadji_jarvisa(t)
        ocekuje = s.expect and time.time() < s.expect_do
        if not wake and not ocekuje: return
        t = t.strip(" ,.!?"); s.expect = False
        if wake: s.reaktor_zvuk()
        if t:
            if trazi_ekran(t):
                s.ui(lambda c=t: s.pitaj_o_ekranu(c, True))
            else:
                s.ui(lambda c=t: (s.pokazi(True), s.posalji(c)))
        else:
            s.expect, s.expect_do = True, time.time() + 12
            s.ui(lambda: (s.pokazi(True), s.add("ai", ("Slušam, " + jarvis.IME + ".") if getattr(jarvis, "IME", "") else "Slušam.", False), s.set_state("listen")))

    def mic_once(s):
        if s.busy: return
        if s.slusa:                                                 # stalno slušanje radi: sljedeća rečenica je naredba
            s.expect, s.expect_do = True, time.time() + 12
            s.set_state("listen"); return
        threading.Thread(target=s._jednom, daemon=True).start()     # stalno slušanje je isključeno: slušaj jednom

    def _jednom(s):
        try:
            import speech_recognition as sr
        except ImportError:
            s.ui(lambda: s.add("err", "Za mikrofon instaliraj: python -m pip install SpeechRecognition pyaudio")); return
        t = ""
        try:
            r = sr.Recognizer()
            with sr.Microphone() as izvor:
                s.expect_do = time.time() + 14
                s.ui(lambda: s.set_state("listen"))
                r.adjust_for_ambient_noise(izvor, 0.4)
                audio = r.listen(izvor, timeout=8, phrase_time_limit=15)
            t = r.recognize_google(audio, language="hr-HR")
        except (sr.WaitTimeoutError, sr.UnknownValueError):
            t = ""
        except BaseException as e:
            s.ui(lambda: (s.add("err", "Mikrofon nije dostupan (provjeri pyaudio i dozvolu za mikrofon): " + str(e)[:80]),
                          s.set_state("idle")))
            return
        _, ostatak = nadji_jarvisa(t)
        t = ostatak.strip() or t
        if t: s.ui(lambda c=t: s.posalji(c))
        else: s.ui(lambda: (s.add("err", "Nisam te čuo, pokušaj ponovo."), s.set_state("idle")))

    def zatvori(s):
        if s.gasi: return
        s.stop_slusanje(); s.govor.stop()
        try:
            import winsound
            moze = (not s.tihi) and s.efekat and os.path.exists(WAV_OFF)
        except Exception:
            moze = False
        if not moze:
            s.kraj(); return
        if s.panel_on: s.toggle_panel()
        s.pokazi(); s.gasi, s.gasi_t0 = True, time.time()
        s.set_state("idle", "GASIM REAKTOR...")
        winsound.PlaySound(WAV_OFF, winsound.SND_FILENAME | winsound.SND_ASYNC)
        s.root.after(1900, s.kraj)

    def start_tray(s):
        """Ikonica pored sata (uvijek prisutna dok Jarvis radi); desni klik daje meni."""
        try:
            import pystray
            from PIL import Image
        except Exception:
            s.cuo_set("Za ikonicu pored sata: python -m pip install pystray"); return
        try:
            img = Image.open(res("jarvis.ico")).convert("RGBA").resize((64, 64))
            pokazi = lambda icon=None, item=None: s.ui(lambda: s.pokazi(False))
            meni = pystray.Menu(
                pystray.MenuItem("Pokaži Jarvisa", pokazi, default=True),
                pystray.MenuItem("Sakrij", lambda icon=None, item=None: s.ui(s.sakrij)),
                pystray.MenuItem("Tihi mod", lambda icon=None, item=None: s.ui(s.toggle_tihi), checked=lambda item: s.tihi),
                pystray.MenuItem("Stalno slušanje", lambda icon=None, item=None: s.ui(s.toggle_stalno), checked=lambda item: s.stalno),
                pystray.Menu.SEPARATOR,
                pystray.MenuItem("Ugasi Jarvisa", lambda icon=None, item=None: s.ui(s.zatvori)))
            s.tray = pystray.Icon("Jarvis", img, "J.A.R.V.I.S. MK II", meni)
            s.tray.run_detached()
        except Exception:
            prijavi_gresku(traceback.format_exc(), prikazi=False)

    def kraj(s):
        try:
            if s.tray: s.tray.stop()
        except Exception: pass
        try: os.remove(FLAG)
        except Exception: pass
        try: s.root.destroy()
        except Exception: pass
        os._exit(0)


def main():
    try:
        App().root.mainloop()
    except BaseException:
        prijavi_gresku(traceback.format_exc())

if __name__ == "__main__":
    main()
